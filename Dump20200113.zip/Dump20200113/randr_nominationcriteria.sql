-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: randr
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nominationcriteria`
--

DROP TABLE IF EXISTS `nominationcriteria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nominationcriteria` (
  `CRITERIA_ID` int(11) NOT NULL AUTO_INCREMENT,
  `REWARD_TYPE` varchar(200) DEFAULT NULL,
  `CRITERIA` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`CRITERIA_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nominationcriteria`
--

LOCK TABLES `nominationcriteria` WRITE;
/*!40000 ALTER TABLE `nominationcriteria` DISABLE KEYS */;
INSERT INTO `nominationcriteria` VALUES (1,'Innovation_Award','Complexity of the work'),(2,'Innovation_Award','How did the project contribute towards increased satisfaction with the customer?'),(3,'Innovation_Award','How did innovation contribute to revenue?'),(4,'Innovation_Award','How did employee\'s innovative impact directly benefit the Organization?'),(5,'Innovation_Award','What  leadership characteristics did emp take with innovative project?'),(6,'Innovation_Award','How did the project contribute to cost to the Org?'),(7,'Innovation_Award','Potential of Innovation to be utilized in future'),(8,'Innovation_Award','Culture Cornerstones Applicable with detailed examples against each'),(9,'Outstanding_FLM_of_the_Quarter','FLM Training Programs Completed'),(10,'Outstanding_FLM_of_the_Quarter','How has FLM\'s efforts positively impacted the Organization?'),(11,'Outstanding_FLM_of_the_Quarter','How has FLM contributed to revenue?'),(12,'Outstanding_FLM_of_the_Quarter','How has FLM efforts aligned with Culture Centricity?'),(13,'Outstanding_FLM_of_the_Quarter','How has FLM reduced cost?'),(14,'Outstanding_FLM_of_the_Quarter','Give at least one instance where the nominee has actually deep delved into an issue to help the team out of a tricky situation?'),(15,'Outstanding_FLM_of_the_Quarter','Which Mphasis values does this nominee display? Substantiating this behavior with any award or testimonial would be an added advantage?'),(16,'Outstanding_FLM_of_the_Quarter','Attrition % for function and team.'),(17,'Outstanding_FLM_of_the_Quarter','Name one instance where nominee showcased one of the Culture Cornerstones'),(18,'Outstanding_FLM_of_the_Quarter','How does this employee drive results in line with enterprise goals?'),(19,'Outstanding_FLM_of_the_Quarter','How does this employee Promote Innovation, Experimentation and entrepreneurship in the workplace?'),(20,'Manager_of_the_Quarter','Level of nominee’s business understanding?'),(21,'Manager_of_the_Quarter','Target v/s actual numbers achieved consistently, GM, CSAT'),(22,'Manager_of_the_Quarter','Quality of customer relationship'),(23,'Manager_of_the_Quarter','Please describe instance where manager acted as a culture ambassador to cascade to his/her team?'),(24,'Manager_of_the_Quarter','How has manager contributed to revenue growth?'),(25,'Manager_of_the_Quarter','How has manager contributed to overall relationship with customer?'),(26,'Manager_of_the_Quarter','How has manager enhanced overall cost?'),(27,'Manager_of_the_Quarter','Attrition % and MAPLE scores'),(28,'Manager_of_the_Quarter','Innovative practices adopted'),(29,'Manager_of_the_Quarter','How has manager gone the extra mile to support his/her team and the Organization as a while?'),(30,'Manager_of_the_Quarter','Please give instance(s) where nominee was faced with diffucult task and ensured his/her team was successful'),(31,'Program_of_the_Quarter','Differentiated component ( pricing/solution/revenue)'),(32,'Program_of_the_Quarter','how has team gone the extra mile in this program to ensure success?'),(33,'Program_of_the_Quarter','What was this program\'s impact on cost?'),(34,'Program_of_the_Quarter','How has this program contributed towards the benefit of the Organization?'),(35,'Program_of_the_Quarter','Competition tackled'),(36,'Program_of_the_Quarter','Satisfaction of Customer (Client Appreciation)'),(37,'Program_of_the_Quarter','What was this program\'s Impact on revenue'),(38,'Program_of_the_Quarter','Competitive conversion/innovative pricing'),(39,'Program_of_the_Quarter','Quality of Delivery'),(40,'Client_Appreciation','What is the value additon brought to customer by the individual?'),(41,'Client_Appreciation','Complexity of the work'),(42,'Client_Appreciation','Team Size');
/*!40000 ALTER TABLE `nominationcriteria` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-13 15:21:28
