-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: randr
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `voucherdata`
--

DROP TABLE IF EXISTS `voucherdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voucherdata` (
  `VOUCHER_ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMP_ID` int(10) DEFAULT NULL,
  `EMP_NAME` varchar(45) DEFAULT NULL,
  `POINTS` int(10) DEFAULT NULL,
  `ALLOTED_DATE` date DEFAULT NULL,
  `QUARTER` varchar(45) DEFAULT NULL,
  `YEAR` int(10) DEFAULT NULL,
  `REWARD_TYPE` varchar(45) DEFAULT NULL,
  `TERM` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`VOUCHER_ID`),
  UNIQUE KEY `Unique` (`EMP_ID`,`EMP_NAME`,`POINTS`,`QUARTER`,`YEAR`,`REWARD_TYPE`,`TERM`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voucherdata`
--

LOCK TABLES `voucherdata` WRITE;
/*!40000 ALTER TABLE `voucherdata` DISABLE KEYS */;
INSERT INTO `voucherdata` VALUES (1,2347303,'Rashmi M N',500,'2019-12-12','Q1',2019,NULL,NULL),(2,2370669,'Pranjal Goyal',600,'2020-01-15','Q1',2019,NULL,NULL),(105,2373950,'Sarika Singh',400,'2020-01-21','Q1',2019,'Client_Appreciation','09-2019'),(112,2370669,'Pranjal Goyal',800,'2020-01-22','Q1',2019,'Weekend Interview',''),(113,2347303,'Revati Reddy',300,'2020-01-22','Q1',2019,'Weekend Interview',''),(114,2369974,'Aakash Tanwar',500,'2020-01-22','Q1',2019,'Weekend Interview','');
/*!40000 ALTER TABLE `voucherdata` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-23 14:43:59
