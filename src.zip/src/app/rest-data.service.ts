import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { LoginViewComponent } from './login-view/login-view.component';

@Injectable({
  providedIn: 'root'
})
export class RestDataService {

  private readCompOffAPI = "http://172.17.51.9:8080/readCompOff";
  private employeeDetailsAPI = "http://172.17.57.9:8080/Emprewards/all";
  private loginInfoAPI = "http://172.17.57.9:8080/employeeRole/role/";

  constructor(private httpClient: HttpClient) { }

  public compOffGetRequest(){
    return this.httpClient.get(this.readCompOffAPI);
  }

  public allEmployeeDetailsRequest(){
    return this.httpClient.get(this.employeeDetailsAPI);
  }

  public loginInfoRequest(loginForm: LoginViewComponent){
    return this.httpClient.post(this.loginInfoAPI,loginForm);
  }

}