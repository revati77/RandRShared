import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FileUploadModule} from 'ng2-file-upload';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ClientViewComponent } from './client-view/client-view.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { ManagerViewComponent } from './manager-view/manager-view.component';
import { AdminViewComponent } from './admin-view/admin-view.component';
import { LoginViewComponent } from './login-view/login-view.component';
import {ClientAppreciationComponent} from './client-appreciation/client-appreciation.component';
import { WeekendInterviewComponent } from './weekend-interview/weekend-interview.component';
import { MonthlyAwardComponent } from './monthly-award/monthly-award.component';
import { PocComponent } from './poc/poc.component';


@NgModule({
  declarations: [
    AppComponent,
    ClientViewComponent,
    FileUploadComponent,
    ManagerViewComponent,
    AdminViewComponent,
    LoginViewComponent,
    ClientAppreciationComponent,
    WeekendInterviewComponent,
    MonthlyAwardComponent,
    PocComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FileUploadModule,
    FormsModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
