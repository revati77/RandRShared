import { Component} from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import {RestDataService} from '../rest-data.service' ;

@Component({
  selector: 'app-login-view',
  templateUrl: './login-view.component.html',
  styleUrls: ['./login-view.component.css']
})
export class LoginViewComponent {

 loginData :any[];
  constructor(private restDataService: RestDataService) {}
  loginForm = new FormGroup({
  
    employeeId: new FormControl(''),
    password: new FormControl('')
  });

  

  onSubmit() {
    
    console.warn(this.loginForm.value);
    this.restDataService.loginInfoRequest(this.loginForm.value).subscribe((resp: any)=>{
      console.log(resp);
    })

  }

}








// implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }
