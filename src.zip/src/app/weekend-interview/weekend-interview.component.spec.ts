import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeekendInterviewComponent } from './weekend-interview.component';

describe('WeekendInterviewComponent', () => {
  let component: WeekendInterviewComponent;
  let fixture: ComponentFixture<WeekendInterviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeekendInterviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeekendInterviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
