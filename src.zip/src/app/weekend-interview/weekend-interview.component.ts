import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weekend-interview',
  templateUrl: './weekend-interview.component.html',
  styleUrls: ['./weekend-interview.component.css']
})
export class WeekendInterviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
