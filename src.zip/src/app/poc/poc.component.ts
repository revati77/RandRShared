import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-poc',
  templateUrl: './poc.component.html',
  styleUrls: ['./poc.component.css']
})
export class PocComponent implements OnInit {

  public questions: any[] =[{
    comment: ''
  }]

  constructor() { }

  ngOnInit() {
  }

  addQuestion() {
    this.questions.push({
      comment:''
    })
  }

  removeQuestion(i: number) {
    this.questions.splice(i,1);
  }
  logValue() {
    console.log(this.questions);
  }

}
