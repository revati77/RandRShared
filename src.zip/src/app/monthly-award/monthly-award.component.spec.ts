import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MonthlyAwardComponent } from './monthly-award.component';

describe('MonthlyAwardComponent', () => {
  let component: MonthlyAwardComponent;
  let fixture: ComponentFixture<MonthlyAwardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MonthlyAwardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MonthlyAwardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
