import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-monthly-award',
  templateUrl: './monthly-award.component.html',
  styleUrls: ['./monthly-award.component.css']
})
export class MonthlyAwardComponent implements OnInit {

  public questions: any[] =[{
    comment: ''
  }]

  constructor() { }

  ngOnInit() {
  }

  addQuestion() {
    this.questions.push({
      comment:''
    })
  }

  removeQuestion(i: number) {
    this.questions.splice(i,1);
  }
  logValue() {
    console.log(this.questions);
  }

}
