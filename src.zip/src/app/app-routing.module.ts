import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientViewComponent } from './client-view/client-view.component';
import {FileUploadComponent} from './file-upload/file-upload.component';
import {ManagerViewComponent} from './manager-view/manager-view.component';
import {AdminViewComponent} from './admin-view/admin-view.component';
import {LoginViewComponent} from './login-view/login-view.component';
import {ClientAppreciationComponent} from './client-appreciation/client-appreciation.component';
import {WeekendInterviewComponent} from './weekend-interview/weekend-interview.component';
import {MonthlyAwardComponent} from './monthly-award/monthly-award.component';
import {PocComponent} from './poc/poc.component';


const routes: Routes = [
  {path: 'employee-view',component: ClientViewComponent},
  {path: 'file-upload',component: FileUploadComponent},
  {path: 'manager-view',component: ManagerViewComponent},
  {path: 'admin-view',component: AdminViewComponent},
  {path: 'login-view',component: LoginViewComponent},
  {path: 'client-appreciation',component: ClientAppreciationComponent},
  {path: 'weekend-interview',component: WeekendInterviewComponent},
  {path: 'monthly-award',component: MonthlyAwardComponent},
  {path: 'poc',component: PocComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
