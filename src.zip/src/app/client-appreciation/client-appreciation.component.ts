import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-appreciation',
  templateUrl: './client-appreciation.component.html',
  styleUrls: ['./client-appreciation.component.css']
})
export class ClientAppreciationComponent implements OnInit {

  public questions: any[] =[{
    comment: ''
  }]

  constructor() { }

  ngOnInit() {
  }

  addQuestion() {
    this.questions.push({
      comment:''
    })
  }

  removeQuestion(i: number) {
    this.questions.splice(i,1);
  }
  logValue() {
    console.log(this.questions);
  }

}
