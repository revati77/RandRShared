import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientAppreciationComponent } from './client-appreciation.component';
import { Component } from '@angular/core';

describe('ClientAppreciationComponent', () => {
  let component: ClientAppreciationComponent;
  let fixture: ComponentFixture<ClientAppreciationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientAppreciationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientAppreciationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
