import { Component, OnInit } from '@angular/core';
import {RestDataService } from '../rest-data.service';

@Component({
  selector: 'app-client-view',
  templateUrl: './client-view.component.html',
  styleUrls: ['./client-view.component.css']
})
export class ClientViewComponent implements OnInit {

  employees = [];

  constructor(private restDataService: RestDataService) { }

  ngOnInit() {
    this.restDataService.allEmployeeDetailsRequest().subscribe((restData: any[])=>{
      console.log(restData);
      this.employees = restData;
  })
  }
  
}
