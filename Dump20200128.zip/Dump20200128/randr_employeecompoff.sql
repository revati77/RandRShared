-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: randr
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employeecompoff`
--

DROP TABLE IF EXISTS `employeecompoff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employeecompoff` (
  `COMPOFF_ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMP_ID` int(11) DEFAULT NULL,
  `EMP_NAME` varchar(45) DEFAULT NULL,
  `COMPOFF_STATUS` varchar(45) DEFAULT NULL,
  `ABSENCE_TYPE` varchar(45) DEFAULT NULL,
  `START_DATE` date DEFAULT NULL,
  `END_DATE` date DEFAULT NULL,
  `LOB` varchar(45) DEFAULT NULL,
  `PROJECT_ID` int(11) DEFAULT NULL,
  `PROJECT_NAME` varchar(45) DEFAULT NULL,
  `LOCATION` varchar(45) DEFAULT NULL,
  `DELIVERY_MANAGER` varchar(45) DEFAULT NULL,
  `PART_OF_WEEKEND_INTERVIEW` varchar(45) DEFAULT NULL,
  `QUARTERLY_VOUCHER_STATUS` varchar(45) DEFAULT NULL,
  `DATE_OF_INTERVIEW_WORK` date DEFAULT NULL,
  `REASON` varchar(45) DEFAULT NULL,
  `COMMENTS` varchar(45) DEFAULT NULL,
  `EXCEPTION` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`COMPOFF_ID`),
  UNIQUE KEY `Unique` (`EMP_ID`,`EMP_NAME`,`COMPOFF_STATUS`,`ABSENCE_TYPE`,`START_DATE`,`END_DATE`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employeecompoff`
--

LOCK TABLES `employeecompoff` WRITE;
/*!40000 ALTER TABLE `employeecompoff` DISABLE KEYS */;
INSERT INTO `employeecompoff` VALUES (100,2373950,'SARIKA SINGH','Completed','Compensatory off','2019-04-15','2019-04-15','ASSET & WEALTH MANAGEMENT',92409,'UK-IPB_OLYMPIC_Upgrade_2016','Bangalore','Ajay',NULL,'VoucherAlloted','2019-04-10',NULL,NULL,NULL),(101,2370669,'PRANJAL GOYAL','Completed','Compensatory off','2019-10-10','2019-10-10','CIB-MARKETS',93840,'CIB IS-MIRO_EqFI Mana-16379','Mumbai','Chetan','2019-06-11','VoucherAlloted','2019-06-11','Interview','Attended Weekend Interview','Yes'),(102,2373950,'SARIKA SINGH','Completed','Compensatory off','2019-10-15','2019-10-16','ASSET & WEALTH MANAGEMENT',92409,'UK-IPB_OLYMPIC_Upgrade_2016','Bangalore','Ajay',NULL,'VoucherAlloted','2019-10-10','Billable','Came on Weekend','No'),(103,2370669,'PRANJAL GOYAL','Completed','Compensatory off','2019-10-16','2019-10-16','CIB-MARKETS',93840,'CIB IS-MIRO_EqFI Mana-16379','Mumbai','Chetan','2019-11-21, 2019-12-11','VoucherAlloted','2019-11-21','Interview','Attended Weekend Interview','Yes');
/*!40000 ALTER TABLE `employeecompoff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-28 15:55:43
