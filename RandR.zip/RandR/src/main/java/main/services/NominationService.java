package main.services;

import main.beans.NominationEntity;
import main.beans.NominationRemark;
import main.repositories.NominationRemarkRepository;
import main.repositories.NominationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class NominationService {

    @Autowired
    private NominationRepository nominationRepository;

    @Autowired
    private NominationRemarkRepository nominationRemarkRepository;

    //    To save
    public NominationEntity save(NominationEntity nominationEntity) {

        nominationRemarkRepository.saveAll( nominationEntity.getNominationRemarkList() );
        return nominationRepository.save( nominationEntity );
    }

    // retrieve all employeerole details
    public List<NominationEntity> findAll() {
        return nominationRepository.findAll();
    }

    //   Get by an id
    public Optional<NominationEntity> getId(Integer nomineeId) {
        return nominationRepository.findByNomineeid( nomineeId );

    }

    //  to update
    public NominationEntity update(NominationEntity nominationEntity) {
        return nominationRepository.save( nominationEntity );
    }

    // insert nomination and remarks
    @Transactional
    public NominationEntity saveNomination(NominationEntity nominationEntity) {

        NominationEntity nominationEntity1 = nominationRepository.save( nominationEntity );
        Long nominationId = nominationEntity1.getId();
        List<NominationRemark> nominationRemarkList = nominationEntity1.getNominationRemarkList();

        for (int i = 0; i < nominationRemarkList.size(); i++) {
            nominationRemarkList.get( i ).setId( nominationId );
        }

        nominationRemarkList = nominationRemarkRepository.saveAll( nominationRemarkList );
        nominationEntity1.setNominationRemarkList( nominationRemarkList );
        return nominationEntity1;
    }

}
