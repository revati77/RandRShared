package main.services;

import main.beans.EmployeeEntity;
import main.excel.ExcelReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@Component
public class ExcelService {

    @Autowired
    private ExcelReader excelReader;

    public List<EmployeeEntity> readExcel(MultipartFile file) throws IOException, ParseException {
        List<EmployeeEntity> employeeEntities = excelReader.read(file);
        return employeeEntities;
    }

}
