package main.services;

import main.beans.EmployeeCompoff;
import main.repositories.EmployeeEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FetchCompOffEligibility {

    @Autowired
    EmployeeEntityRepository employeeEntityRepository;


    public String fetchCompOffEligibility(EmployeeCompoff employeeCompoff)
    {

        String compOffEligibility = employeeEntityRepository.findBYParameters(employeeCompoff.getEmployee_id(),employeeCompoff.getReward_type(),employeeCompoff.getDate_of());

        return compOffEligibility;
    }
}
