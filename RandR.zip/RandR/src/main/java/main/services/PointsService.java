package main.services;

import main.beans.Points;
import main.repositories.PointsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PointsService
{
    @Autowired
    private PointsRepository pointsRepository;

   /* to save*/
    public Points save(Points points)
    {
        return pointsRepository.save(points);
    }

   /* to get all*/
    public List<Points> getAll() {
        return pointsRepository.findAll();
    }

    /*to get by id*/
    public Optional<Points> getById(String reward_type) {
        return pointsRepository.findById(reward_type);
    }

    /*    to update*/
    public Points update(Points points) {
        return pointsRepository.save(points);
    }
}
