package main.services;

import main.beans.NominationCriteriaDetails;
import main.repositories.NominationCriteriaDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NominationCriteriaDetailsService {

    @Autowired
    private NominationCriteriaDetailsRepository nominationCriteriaDetailsRepository;

//To save

    public NominationCriteriaDetails save(NominationCriteriaDetails nominationCriteriaDetails) {
        return nominationCriteriaDetailsRepository.save( nominationCriteriaDetails );
    }

    // retrieve all nomination criteria details
    public List<NominationCriteriaDetails> findAll() {
        return nominationCriteriaDetailsRepository.findAll();
    }

    //    Get by an reward type
    public List<NominationCriteriaDetails> getByRewardType(String REWARD_TYPE) {
        return nominationCriteriaDetailsRepository.getByRewardType(REWARD_TYPE);
    }
}
