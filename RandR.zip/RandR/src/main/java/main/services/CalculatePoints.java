package main.services;

import main.beans.Points;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;

@Component
public class CalculatePoints {

    private static List<Points> points;
    @Autowired
    private PointsService pointsService;

    private void getAllPoints() {
        points = pointsService.getAll();
    }

    public Integer CalculateTotalPoints(String reward_type, Integer interview) {
        Integer point = 1;
        if (CollectionUtils.isEmpty( points )) {
            getAllPoints();
        }
        Optional<Points> optionalPoints = points.stream().filter( pointData -> pointData.getRewardType().equals( reward_type ) ).findFirst();
        if (optionalPoints.isPresent()) {
            point = optionalPoints.get().getPoints();
        }

        if (interview != null) {
            point = point * interview;
        }
        return point;

    }


}
