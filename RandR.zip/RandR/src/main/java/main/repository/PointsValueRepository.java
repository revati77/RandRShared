package main.repository;

import main.bean.PointsValue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Repository
public interface PointsValueRepository extends JpaRepository<PointsValue, String> {

    @Modifying
    @Transactional
    @Query(value="DELETE FROM PointsValue WHERE pointsId = ?1")
    void deleteById(Integer pointsId);

    @Query(value ="SELECT e FROM PointsValue e WHERE e.rewardType = ?1")
    PointsValue findByRewardType(String rewardType);

}
