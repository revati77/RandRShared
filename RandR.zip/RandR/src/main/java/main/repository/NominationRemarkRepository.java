package main.repository;

import main.bean.NominationRemark;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NominationRemarkRepository extends JpaRepository<NominationRemark, Long> {
}
