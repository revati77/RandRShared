package main.repository;


import main.bean.EmployeeRewards;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRewardsRepository extends JpaRepository<EmployeeRewards, Long> {
    @Query(value ="select e from employeerewards e where e.EMP_ID=?1",  nativeQuery = true)
    List<EmployeeRewards> findByEmpId(Integer EMP_ID);

    @Query(value ="select e from employeerewards e where e.MANAGER_ID=?1",  nativeQuery = true)
    List<EmployeeRewards> findByManagerId(Integer MANAGER_ID);

//    @Query(value ="Update e employeerewards set e.status=?1 where e.EMP_ID=?2, e.REWARD_TYPE?3, e.SKILL?4, e.LOCATION?5, e.DATE_OF?6",  nativeQuery = true)
//    EmployeeRewards updateRewardStatus(@Param("status") String STATUS, @Param("empId") Integer EMP_ID, @Param("rewardType") String REWARD_TYPE, @Param("skill") String SKILL, @Param("location") String LOCATION, @Param("dateof") String DATE_OF);
}
