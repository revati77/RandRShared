package main.repository;

import main.bean.NominationCriteria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface NominationCriteriaRepository extends JpaRepository<NominationCriteria, Integer> {
    @Query("select r from NominationCriteria r where r.rewardType=?1")
    List<NominationCriteria> findByRewardType(String reward_type);
}
