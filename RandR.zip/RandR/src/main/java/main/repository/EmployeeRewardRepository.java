package main.repository;


import main.bean.EmployeeReward;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface EmployeeRewardRepository extends JpaRepository<EmployeeReward, Long> {
    @Query(value = "select * from employeerewards e where e.EMP_ID=?1", nativeQuery = true)
    List<EmployeeReward> findByEmpId(Integer EMP_ID);

    @Query(value = "select * from employeerewards e where e.MANAGER_ID=?1", nativeQuery = true)
    List<EmployeeReward> findByManagerId(Integer MANAGER_ID);

    @Modifying
    @Transactional
    @Query(value="DELETE FROM EmployeeReward WHERE id = ?1", nativeQuery = true)
    void deleteById(Long id);

    @Modifying
    @Transactional
    @Query(value="UPDATE EmployeeReward e SET e.status=?2 WHERE e.id = ?1")
    void updateStatus(Long id, String status);

    @Modifying
    @Transactional
    @Query(value="UPDATE EmployeeReward e SET e.advanceCompoff=?2 WHERE e.id = ?1")
    void updateAdvanceCompOffRepo(Long id,String advanceCompOff);

    @Query(value ="SELECT * FROM employeerewards  WHERE EMP_ID=?1 AND DATE_OF BETWEEN startDate=?3 AND endDate=?2", nativeQuery = true)
    List<EmployeeReward> toGetByQuarterDate(Integer empId, Date endDate, Date startDate);

    @Query(value="select  * from employeerewards e where e.EMP_ID=empId, e.DATE_OF=date", nativeQuery = true)
    EmployeeReward getByDate(Integer empId, Date date);
}
