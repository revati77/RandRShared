package main.repository;


import main.bean.EmployeeReward;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface EmployeeRewardRepository extends JpaRepository<EmployeeReward, Long> {
    @Query(value = "select * from employeerewards e where e.EMP_ID=?1", nativeQuery = true)
    List<EmployeeReward> findByEmpId(Integer EMP_ID);

    @Query(value = "select * from employeerewards e where e.MANAGER_ID=?1", nativeQuery = true)
    List<EmployeeReward> findByManagerId(Integer MANAGER_ID);

    @Modifying
    @Transactional
    @Query(value="DELETE FROM EmployeeReward WHERE id = ?1", nativeQuery = true)
    void deleteById(Long id);

    @Modifying
    @Transactional
    @Query(value="UPDATE EmployeeReward e SET e.status=?2 WHERE e.id = ?1")
    void updateStatus(Long id, String status);

    @Modifying
    @Transactional
    @Query(value="UPDATE EmployeeReward e SET e.advanceCompoff=?2, e.noOfPoints=?3 WHERE e.id = ?1")
    void updateAdvanceCompOffRepo(Long id,String advanceCompoff, Integer noOfPoints);

    @Query(value ="SELECT e FROM EmployeeReward e WHERE e.status=:status AND e.advanceCompoff=:advanceCompoff AND (e.dateOf BETWEEN :startDate AND :endDate)")
    List<EmployeeReward> getQuarterList(@Param("status")String status, @Param("advanceCompoff")String advanceCompoff, @Param("startDate") Date date1,@Param("endDate") Date date2);

    @Query(value ="SELECT e FROM EmployeeReward e WHERE e.empId=:empId AND e.status=:status AND e.advanceCompoff=:advanceCompoff AND e.dateOf BETWEEN :startDate AND :endDate")
    List<EmployeeReward> getQuarterListByEmployee(@Param("empId")Integer empId, @Param("status")String status, @Param("advanceCompoff")String advanceCompoff, @Param("startDate") Date date1, @Param("endDate") Date date2);

    @Query(value ="SELECT e.dateOf FROM EmployeeReward e WHERE e.empId=:empId AND e.dateOf BETWEEN :startDate AND :endDate")
    List<Date> getQuarterlyDateList(@Param("empId")Integer empId, @Param("startDate") Date date1, @Param("endDate") Date date2);

    @Query(value ="SELECT e.status FROM EmployeeReward e WHERE e.empId=:empId AND e.dateOf =:dateOf")
    String getStatus(@Param("empId")Integer empId, @Param("dateOf") Date dateOf);

    @Query(value ="SELECT e FROM EmployeeReward e WHERE STATUS IN :statusList AND e.dateOf BETWEEN :startDate AND :endDate")
    List<EmployeeReward> downloadWeekendDetails(@Param("statusList") List<String> statusList,@Param("startDate") Date startDate, @Param("endDate") Date endDate);
}