package main.repository;


import main.bean.EmployeeReward;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface EmployeeRewardRepository extends JpaRepository<EmployeeReward, Long> {
    @Query(value = "select * from employeerewards e where e.EMP_ID=?1", nativeQuery = true)
    List<EmployeeReward> findByEmpId(Integer EMP_ID);

    @Query(value = "select * from employeerewards e where e.MANAGER_ID=?1", nativeQuery = true)
    List<EmployeeReward> findByManagerId(Integer MANAGER_ID);

    @Modifying
    @Transactional
    @Query(value="DELETE FROM EmployeeReward WHERE id = ?1", nativeQuery = true)
    void deleteById(Long id);

    @Modifying
    @Transactional
    @Query(value="UPDATE EmployeeReward e SET e.status=?2 WHERE e.id = ?1")
    void updateStatus(Long id, String status);

    @Modifying
    @Transactional
    @Query(value="UPDATE EmployeeReward e SET e.advanceCompoff=?2 WHERE e.id = ?1")
    void updateAdvanceCompOffRepo(Long id,String advanceCompOff);

    @Query(value ="SELECT e FROM EmployeeReward e WHERE e.empId=:empId AND e.dateOf BETWEEN :startDate AND :endDate")
    List<EmployeeReward> toGetByQuarterDate(@Param("empId")Integer empId, @Param("endDate") Date date1, @Param("startDate") Date date2);

    @Query(value="SELECT  e from EmployeeReward e where e.empId=?1 AND e.dateOf=?2 ")
    EmployeeReward getByDate(Integer empId, Date date);


    @Query(value ="SELECT e FROM EmployeeReward e WHERE e.status=:status AND (e.dateOf BETWEEN :startDate AND :endDate)")
    List<EmployeeReward> getQuarterList(@Param("status")String status, @Param("startDate") Date date1,@Param("endDate") Date date2);

    @Modifying
    @Transactional
    @Query(value="UPDATE EmployeeReward e SET e.advanceCompoff=?2 WHERE e.id = ?1")
    void updateVoucherStatus(Long id,String advanceCompOff);
}