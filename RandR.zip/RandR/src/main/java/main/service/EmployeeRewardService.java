package main.service;

import main.bean.EmployeeReward;
import main.repository.EmployeeRewardRepository;
import main.reports.WeekendDetailsDownload;
import main.util.WeekendExcelReader;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeRewardService {

    @Autowired
    private EmployeeRewardRepository employeeRewardRepository;

    @Autowired
    private WeekendExcelReader weekendExcelReader;

    @Autowired
    private WeekendDetailsDownload weekendDetailsDownload;

    //   To save
    public EmployeeReward save(EmployeeReward employeeReward) {
        return employeeRewardRepository.save( employeeReward );
    }

    // retrieve all employeerole details
    public List<EmployeeReward> findAll() {
        return employeeRewardRepository.findAll();
    }

    //    Get by employee id
    public List<EmployeeReward> getId(Integer EMP_ID) {
        return employeeRewardRepository.findByEmpId( EMP_ID );
    }

    //    Get by manager id
    public List<EmployeeReward> getByManagerId(Integer EMP_ID) {
        return employeeRewardRepository.findByManagerId( EMP_ID );
    }

    //    to update
    public EmployeeReward update(EmployeeReward employeeReward) {
        return employeeRewardRepository.save( employeeReward );
    }

    //To delete all
    public void delete(Long id) {
        employeeRewardRepository.deleteById( id );
    }

    //To Update Status
    public void statusUpdate(Long id, String status) {
        long id1 = id;
        String status1 = status;
        if (status1.equals( "Approved" ) || status1.equals( "Rejected" )) {
            employeeRewardRepository.updateStatus( id1, status1 );
        }
    }

    public Optional<EmployeeReward> getById(Long id) {
        return employeeRewardRepository.findById( id );
    }

    public List<EmployeeReward> readExcel(MultipartFile file, Integer empId) throws IOException, ParseException {
        List<EmployeeReward> employeeEntities = weekendExcelReader.read( file, empId );
        return employeeEntities;
    }

    //To update AdvanceCompOff
    public List<EmployeeReward> updateAdvanceCompOff(List<Long> idList, String advanceCompOff) {
        for (Long id : idList) {
            employeeRewardRepository.updateAdvanceCompOffRepo( id, advanceCompOff, 0);
        }
        return employeeRewardRepository.findAll();
    }

    /*  to retrieve weekend details between two dates*/
    public XSSFWorkbook downloadWeekendDetails(Date startDate, Date endDate,List<String> statusList) {
        return weekendDetailsDownload.downloadWeekendDetails( startDate,endDate,statusList );
    }


}