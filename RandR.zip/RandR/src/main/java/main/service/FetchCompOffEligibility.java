package main.service;

import main.bean.EmployeeCompoff;
import main.repository.EmployeeCompoffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FetchCompOffEligibility {

    @Autowired
    EmployeeCompoffRepository employeeCompoffRepository;


    public String fetchCompOffEligibility(EmployeeCompoff employeeCompoff)
    {

        String compOffEligibility = employeeCompoffRepository.findBYParameters(employeeCompoff.getEmployee_id(),employeeCompoff.getReward_type(),employeeCompoff.getDate_of());

        return compOffEligibility;
    }
}
