package main.service;

import main.bean.EmployeeRewards;
import main.repository.EmployeeRewardsRepository;
//import main.util.UpdateRewardStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeRewardsService {

    @Autowired
    private EmployeeRewardsRepository employeeRewardsRepository;

//    @Autowired
//    private UpdateRewardStatusService updateRewardStatusService;

    //   To save
    public EmployeeRewards save(EmployeeRewards employeeRewards) {
        return employeeRewardsRepository.save( employeeRewards );
    }

    // retrieve all employeerole details
    public List<EmployeeRewards> findAll() {
        return employeeRewardsRepository.findAll();
    }

    //    Get by employee id
    public List<EmployeeRewards> getId(Integer EMP_ID) {
        return employeeRewardsRepository.findByEmpId(EMP_ID);
    }

    //    Get by manager id
    public List<EmployeeRewards> getByManagerId(Integer EMP_ID) {
        return employeeRewardsRepository.findByManagerId(EMP_ID);
    }

    //    to update
    public EmployeeRewards update(EmployeeRewards employeeRewards) {
        return employeeRewardsRepository.save(employeeRewards);
    }

    //To delete all
    public void delete(Long id)
    {
        employeeRewardsRepository.deleteById(id);
    }
}
