package main.service;

import main.bean.VoucherData;
import main.repository.VoucherDataRepository;
import main.util.QuarterlyRewardNomination;
import main.util.VoucherDataDownload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileOutputStream;
import java.util.List;

@Service
public class VoucherDataService {

    @Autowired
    private VoucherDataRepository voucherDataRepository;

    @Autowired
    private QuarterlyRewardNomination quarterlyRewardNomination;

    @Autowired
    private VoucherDataDownload voucherDataDownload;

    // to get all
    public List<VoucherData> getAll() {
        return voucherDataRepository.findAll();
    }

    public List<VoucherData> getQuarterlyData(String quarter, Integer year){
        return voucherDataRepository.getQuarterlyData(quarter, year);
    }

    public List<VoucherData> getQuarterlyReward(String quarter, Integer year){
        return quarterlyRewardNomination.quarterlyRewardNomination(quarter, year);
    }

    public FileOutputStream downloadQuarterlyVoucher(String quarter, Integer year){
        return voucherDataDownload.voucherDataDownload(quarter, year);
    }

}
