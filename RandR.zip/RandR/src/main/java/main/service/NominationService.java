package main.service;

import main.bean.Nomination;
import main.bean.NominationRemark;
import main.repository.NominationRemarkRepository;
import main.repository.NominationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class NominationService {

    @Autowired
    private NominationRepository nominationRepository;

    @Autowired
    private NominationRemarkRepository nominationRemarkRepository;

    //    To save
    public Nomination save(Nomination nomination) {

        nominationRemarkRepository.saveAll( nomination.getNominationRemarkList() );
        return nominationRepository.save( nomination );
    }

    // retrieve all employeerole details
    public List<Nomination> findAll() {
        return nominationRepository.findAll();
    }

    //   Get by an id
    public Optional<Nomination> getId(Integer nomineeId) {
        return nominationRepository.findByNomineeid( nomineeId );

    }

    //  to update
    public Nomination update(Nomination nomination) {
        return nominationRepository.save( nomination );
    }

    // insert nomination and remarks
    @Transactional
    public Nomination saveNomination(Nomination nomination) {

        Nomination nomination1 = nominationRepository.save( nomination );
        Long nominationId = nomination1.getId();
        List<NominationRemark> nominationRemarkList = nomination1.getNominationRemarkList();

        nominationRemarkList.stream().forEach( nominationRemark -> nominationRemark.setId( nominationId ) );

        nominationRemarkList = nominationRemarkRepository.saveAll( nominationRemarkList );
        nomination1.setNominationRemarkList( nominationRemarkList );
        return nomination1;
    }

}
