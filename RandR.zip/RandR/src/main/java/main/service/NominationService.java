package main.service;

import main.bean.Nomination;
import main.bean.NominationRemark;
import main.repository.NominationRemarkRepository;
import main.repository.NominationRepository;
import main.util.GetCurrentDate;
import main.util.WeekendExcelReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

@Service
public class NominationService {

    @Autowired
    private NominationRepository nominationRepository;

    @Autowired
    private NominationRemarkRepository nominationRemarkRepository;

    //    To save
    public Nomination save(Nomination nomination) {

        nominationRemarkRepository.saveAll( nomination.getNominationRemarkList() );
        return nominationRepository.save( nomination );
    }

    // retrieve all employeerole details
    public List<Nomination> findAll() {
        return nominationRepository.findAll();
    }

    //   Get by an id
    public Optional<Nomination> getId(Integer nomineeId) {
        return nominationRepository.findByNomineeid( nomineeId );

    }

    //  to update
    @Transactional
    public Nomination update(Nomination nomination) {
        List<NominationRemark> nominationRemarkList = nomination.getNominationRemarkList();
        Nomination nominationParam = nominationRepository.save( nomination );
        List<NominationRemark> nominationRemarkListParam = nominationRemarkRepository.saveAll( nominationRemarkList );
        nominationParam.setNominationRemarkList( nominationRemarkListParam );
        return nominationParam;
    }

    // insert nomination and remarks
    @Transactional
    public Nomination saveNomination(Nomination nomination) throws ParseException {

        //set NominationDate as current date
        nomination.setNominationDate(GetCurrentDate.getCurrentDate());

        //Set default NominationStatus as Pending
        nomination.setNominationStatus("Pending");

        Nomination nominationParam = nominationRepository.save( nomination );
        Long nominationId = nominationParam.getId();
        List<NominationRemark> nominationRemarkList = nominationParam.getNominationRemarkList();

        nominationRemarkList.stream().forEach(nominationRemark -> nominationRemark.setId(nominationId));

        nominationRemarkList = nominationRemarkRepository.saveAll(nominationRemarkList);
        nominationParam.setNominationRemarkList(nominationRemarkList);
        return nominationParam;
    }

    // Upload Nomination excel

    public void saveExcelNomination(MultipartFile file, String rewardType){

    }

}
