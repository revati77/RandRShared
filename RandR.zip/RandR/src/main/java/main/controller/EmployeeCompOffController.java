package main.controller;

import main.bean.EmployeeCompOff;
import main.service.EmployeeCompOffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@RestController
@RequestMapping("/employeeCompOff")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EmployeeCompOffController {

    @Autowired
    private EmployeeCompOffService employeeCompOffService;

    // Read CompOff Details
    @PostMapping("/compOff/{MONTH}/{YEAR}")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeCompOff> compOffExcelReader(@PathVariable("MONTH") final String month, @PathVariable("YEAR") final Integer year, @RequestParam("compOffFile") MultipartFile compOffFile, @RequestParam("employeeProjectInfo") MultipartFile employeeProjectInfo) throws IOException, ParseException {
        return employeeCompOffService.readCompOffExcel( month, year, compOffFile, employeeProjectInfo );
    }

    //To save
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeCompOff createEmployee(@Valid @RequestBody EmployeeCompOff employeeCompOff) {
        return employeeCompOffService.save( employeeCompOff );
    }

    //To retreive all
    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeCompOff> getAll()
    {
        return employeeCompOffService.getAll();
    }

    //To update
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeCompOff> updateCompOffList(@RequestBody List<EmployeeCompOff> employeeCompOffList) {
        return employeeCompOffService.updateCompOffList( employeeCompOffList );
    }

    //To delete using empId
    @DeleteMapping("/deleteByEmpId/{EMP_ID}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteByEmpId(@PathVariable("EMP_ID") final Integer empId)
    {
        employeeCompOffService.deleteByEmpId(empId);
    }

    //To delete using Id
    @DeleteMapping("/deleteByid/{COMPOFF_ID}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteById(@PathVariable("COMPOFF_ID") final Long compOffId)
    {
        employeeCompOffService.deleteById(compOffId);
    }


}
