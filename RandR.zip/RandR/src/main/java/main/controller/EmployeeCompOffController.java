package main.controller;

import main.bean.EmployeeCompOff;
import main.service.EmployeeCompOffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@RestController
@RequestMapping("/employeeCompOff")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EmployeeCompOffController {

    @Autowired
    private EmployeeCompOffService employeeCompOffService;

    // Read CompOff Details
    @PostMapping("/compOff")
    public List<EmployeeCompOff> compOffExcelReader(@RequestParam("compOffFile") MultipartFile compOffFile, @RequestParam("employeeProjectInfo") MultipartFile employeeProjectInfo) throws IOException, ParseException {
        return employeeCompOffService.readCompOffExcel( compOffFile, employeeProjectInfo );
    }

}
