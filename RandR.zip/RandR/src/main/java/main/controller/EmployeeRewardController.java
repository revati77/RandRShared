package main.controller;


import main.bean.EmployeeReward;

import main.service.EmployeeRewardService;
import main.util.ConsolidatedCompOffExcelReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@RestController
@RequestMapping("/employeeRewards")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EmployeeRewardController {

    @Autowired
    private EmployeeRewardService employeeRewardService;

    @Autowired
    private ConsolidatedCompOffExcelReader consolidatedCompOffExcelReader;

    //  to save
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeReward createEmployee(@Valid @RequestBody EmployeeReward employeeReward) {
        return employeeRewardService.save( employeeReward );
    }

    @PostMapping("/excelReader")
    public List<EmployeeReward> excelReader(@RequestParam("file") MultipartFile excelDatafile, @RequestParam("EMP_ID") final Integer empId) throws IOException, ParseException {
        return employeeRewardService.readExcel( excelDatafile, empId );
    }

    // to retrieve all details
    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeReward> getAll() {
        return employeeRewardService.findAll();
    }

    /*  to retrieve by employee id*/
    @GetMapping("/getByEmployeeId/{EMP_ID}")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeReward> getId(@PathVariable("EMP_ID") final Integer EMP_ID) {
        return employeeRewardService.getId( EMP_ID );
    }

    // to retrieve by employee id
    @GetMapping("/getByManagerId/{MANAGER_ID}")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeReward> getByManagerId(@PathVariable("MANAGER_ID") final Integer MANAGER_ID) {
        return employeeRewardService.getByManagerId( MANAGER_ID );
    }

    //  to update
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeReward update(@RequestBody EmployeeReward employeeReward) {
        return employeeRewardService.update( employeeReward );
    }


    //To update status
    @PutMapping("/statusUpdate/{ID}/{STATUS}")
    public void statusUpdate(@PathVariable("ID") final Long id, @PathVariable("STATUS") final String status) {
        employeeRewardService.statusUpdate( id, status );
    }

    //To delete
    @DeleteMapping("/deleteById/{ID}")
    public void delete(@PathVariable("ID") final Long id) {
        employeeRewardService.delete( id );
    }

    //To update AdvanceCompOff
    @PutMapping("/UpdateAdvanceCompOff/{ADVANCE_COMPOFF}")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeReward> updateAdvanceCompOff(@Valid @RequestBody List<Long> idList, @PathVariable("ADVANCE_COMPOFF") final String advanceCompOff)
    {
        return employeeRewardService.updateAdvanceCompOff(idList,advanceCompOff);
    }

    //To retrieve the 3 months details for perticular employee
/*    @GetMapping("/toGetByQuarterDate/{EMP_ID}/{DATE_OF}")
    public List<EmployeeRewards> toGetByQuarterDate(@PathVariable("EMP_ID") final Integer empId, @PathVariable("DATE_OF") final Date date1)
    {
        return employeeRewardsService.toGetByQuarterDate(empId,date1);
    }*/
}
