package main.controller;

import main.bean.EmployeeRewards;
import main.service.ExcelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ExcelController {

    @Autowired
    private ExcelService excelService;

    /*
    @GetMapping("/readExcel")
    public List<EmployeeEntity> readExcel() throws IOException, ParseException {
        List<EmployeeEntity> employeeEntities = excelService.readExcel();
        return employeeEntities;
    }
    */
    @PostMapping("/excelReader")
    public List<EmployeeRewards> excelReader(@RequestParam("file") MultipartFile excelDatafile, @RequestParam("EMP_ID") final Integer empId) throws IOException, ParseException {
        return excelService.readExcel( excelDatafile, empId );
    }
}
