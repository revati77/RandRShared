package main.controller;

import main.bean.NominationCriteria;
import main.service.NominationCriteriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/nominationCriteria")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class NominationCriteriaController {

    @Autowired
    private NominationCriteriaService nominationCriteriaService;

    //  to save
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.OK)
    public NominationCriteria createEmployee(@Valid @RequestBody NominationCriteria nominationCriteria) {
        return nominationCriteriaService.save( nominationCriteria );
    }

    // to retrieve all details
    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<NominationCriteria> getAll() {
        return nominationCriteriaService.findAll();
    }

    // to retrieve by id
    @GetMapping("/getById/{REWARD_TYPE}")
    @ResponseStatus(HttpStatus.OK)
    public List<NominationCriteria> getId(@PathVariable("REWARD_TYPE") final String REWARD_TYPE) {
        return nominationCriteriaService.getId( REWARD_TYPE );
    }

    // to update
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.OK)
    public NominationCriteria update(@RequestBody NominationCriteria nominationCriteria) {
        return nominationCriteriaService.update( nominationCriteria );
    }

    //to delete
    @DeleteMapping("/deleteById/{CRITERIA_ID}")
    @ResponseStatus(HttpStatus.OK)
    public void delete(@PathVariable("CRITERIA_ID") final Integer criteriaId) {
        nominationCriteriaService.delete( criteriaId );
    }

    //to delete
    @DeleteMapping("/deleteByRewardType/{REWARD_TYPE}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteByRewardType(@PathVariable("REWARD_TYPE") final String rewardType) {
        nominationCriteriaService.deleteByRewardType( rewardType );
    }
}
