package main.controller;

import main.service.VoucherDataService;
import main.util.DownloadExcel;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
@RequestMapping("/reports")
@CrossOrigin(origins = "*", allowedHeaders = "*", exposedHeaders = "Content-Disposition")
public class ReportsController {

    @Autowired
    private DownloadExcel downloadExcel;

    @Autowired
    private VoucherDataService voucherDataService;

    @GetMapping(value = "/downloadQuarterlyVoucher/{QUARTER}/{YEAR}/{REWARDTYPE}", produces = "application/vnd.ms-excel;charset=UTF-8")
    @ResponseStatus(HttpStatus.OK)
    public void downloadQuarterlyVoucher(@PathVariable("QUARTER") String quarter, @PathVariable("YEAR") Integer year, @PathVariable("REWARDTYPE") String rewardType, final HttpServletResponse response) throws IOException {

        String excelFileName;

        if (rewardType.equals( "Weekend_Interview" )) {
            excelFileName = "WeekendInterviewVoucherData.xlsx";
        } else {
            excelFileName = "NominationVoucherData.xlsx";
        }
        //ExcelService builts the workbook using POI
        XSSFWorkbook workbook = voucherDataService.downloadQuarterlyVoucher( quarter, year, rewardType );

        downloadExcel.downloadExcel( excelFileName, workbook, response );
    }
}
