package main.controller;

import main.service.VoucherDataService;
import main.util.DownloadExcel;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

@RestController
@RequestMapping("/reports")
@CrossOrigin(origins = "*", allowedHeaders = "*", exposedHeaders = "Content-Disposition")
public class ReportsController {

    @Autowired
    private DownloadExcel downloadExcel;

    @Autowired
    private VoucherDataService voucherDataService;

    @GetMapping(value = "/downloadQuarterlyVoucher/{QUARTER}/{YEAR}", produces = "application/vnd.ms-excel;charset=UTF-8")
    @ResponseStatus(HttpStatus.OK)
    public void downloadQuarterlyVoucher(@PathVariable("QUARTER") String quarter, @PathVariable("YEAR") Integer year, final HttpServletResponse response) throws IOException {

        String excelFileName = "VoucherData.xlsx";
        //ExcelService builts the workbook using POI
        XSSFWorkbook workbook = voucherDataService.downloadQuarterlyVoucher( quarter, year );

        downloadExcel.downloadExcel(excelFileName,workbook, response);
    }
}
