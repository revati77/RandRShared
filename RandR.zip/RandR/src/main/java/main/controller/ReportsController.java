package main.controller;

import main.service.EmployeeRewardService;
import main.service.NominationService;
import main.service.VoucherDataService;
import main.util.DownloadExcel;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

@RestController
@RequestMapping("/reports")
@CrossOrigin(origins = "*", allowedHeaders = "*", exposedHeaders = "Content-Disposition")
public class ReportsController {

    @Autowired
    private DownloadExcel downloadExcel;

    @Autowired
    private VoucherDataService voucherDataService;

    @Autowired
    private EmployeeRewardService employeeRewardService;

    @Autowired
    private NominationService nominationService;

    @GetMapping(value = "/downloadQuarterlyVoucher/{QUARTER}/{YEAR}/{REWARDTYPE}", produces = "application/vnd.ms-excel;charset=UTF-8")
    @ResponseStatus(HttpStatus.OK)
    public void downloadQuarterlyVoucher(@PathVariable("QUARTER") String quarter, @PathVariable("YEAR") Integer year, @PathVariable("REWARDTYPE") String rewardType, final HttpServletResponse response) throws IOException {

        String excelFileName;

        if (rewardType.equals( "Weekend_Interview" )) {
            excelFileName = "WeekendInterviewVoucherData.xlsx";
        } else {
            excelFileName = "NominationVoucherData.xlsx";
        }
        //ExcelService builts the workbook using POI
        XSSFWorkbook workbook = voucherDataService.downloadQuarterlyVoucher( quarter, year, rewardType );

        downloadExcel.downloadExcel( excelFileName, workbook, response );
    }

    //to retrieve weekend details between two dates
    @GetMapping(value ="/downloadWeekendInterviewDetails/{Start_Date}/{End_Date}", produces = "application/vnd.ms-excel;charset=UTF-8")
    @ResponseStatus(HttpStatus.OK)
    public void downloadWeekendDetails(@PathVariable("Start_Date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate, @PathVariable("End_Date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate, final HttpServletResponse response) throws IOException
    {
        String excelFileName = "WeekendInterviewData.xlsx";
        //ExcelService builts the workbook using POI
        XSSFWorkbook workbook = employeeRewardService.downloadWeekendDetails(startDate,endDate);

        downloadExcel.downloadExcel(excelFileName,workbook, response);
    }

    //to retrieve nomination for that quarter who are approved
    @GetMapping(value ="/downloadNominationDetails/{QUARTER}/{YEAR}", produces = "application/vnd.ms-excel;charset=UTF-8")
    @ResponseStatus(HttpStatus.OK)
    public void downloadNominaionDetails(@PathVariable("QUARTER") String quarter, @PathVariable("YEAR") Integer year, final HttpServletResponse response) throws IOException
    {
        String excelFileName = "NominationData.xlsx";
        //ExcelService builts the workbook using POI
        XSSFWorkbook workbook = nominationService.downloadNominaionDetails(quarter,year);

        downloadExcel.downloadExcel(excelFileName,workbook, response);
    }
}
