package main.controller;

import main.bean.Nomination;
import main.service.NominationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/nomination")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class NominationController {

    @Autowired
    private NominationService nominationService;

    //  to save
    @PostMapping("/save")
    public Nomination createEmployee(@Valid @RequestBody Nomination nomination) {
        return nominationService.save( nomination );
    }

    // to retrieve all details
    @GetMapping("/all")
    public List<Nomination> getAll() {
        return nominationService.findAll();
    }

    //  to retrieve by id
    @GetMapping("/getByid/{NOMINEE_ID}")
    public Optional<Nomination> getId(@PathVariable("NOMINEE_ID") final Integer NOMINEE_ID) {
        return nominationService.getId( NOMINEE_ID );
    }

    //  to update
    @PutMapping("/update")
    public Nomination update(@RequestBody Nomination nomination) {
        return nominationService.update( nomination );
    }

    // Save nomination and remarks

    @PostMapping("/saveNomination")
    public Nomination saveNomination(@Valid @RequestBody Nomination nomination) throws ParseException {
        return nominationService.saveNomination( nomination );
    }

    // Save list of nominations uploaded via excel

    @PostMapping("/saveExcelNomination")
    public List<Nomination> saveNomination(@RequestParam("file") MultipartFile excelDatafile, @RequestParam("REWARD_TYPE") final String rewardType) throws ParseException, IOException {
        return nominationService.saveExcelNomination(excelDatafile, rewardType);
   }
}
