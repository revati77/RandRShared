package main.controller;

import main.bean.Nomination;
import main.service.NominationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/nomination")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class NominationController {

    @Autowired
    private NominationService nominationService;

    // to retrieve all details
    @GetMapping("/all")
    public List<Nomination> getAll() {
        return nominationService.findAll();
    }

    //  to retrieve by nominee Id
    @GetMapping("/getByNomineeId/{NOMINEE_ID}")
    public List<Nomination> getByNomineeId(@PathVariable("NOMINEE_ID") final Integer NOMINEE_ID) {
        return nominationService.getByNomineeId( NOMINEE_ID );
    }

    //  to retrieve by Pmo Id
    @GetMapping("/getByPmoId/{PMO_ID}")
    public List<Nomination> getByPmoId(@PathVariable("PMO_ID") final Integer PMO_ID) {
        return nominationService.getByPmoId( PMO_ID );
    }

    //  to retrieve by MANAGER_ID
    @GetMapping("/getByManagerId/{MANAGER_ID}")
    public List<Nomination> getByManagerId(@PathVariable("MANAGER_ID") final Integer managerId) {
        return nominationService.getByManagerId( managerId );
    }

    //  to update
    @PutMapping("/update")
    public Nomination update(@RequestBody Nomination nomination) {
        return nominationService.update( nomination );
    }

    // Save nomination and remarks
    @PostMapping("/saveNomination")
    public Nomination saveNomination(@Valid @RequestBody Nomination nomination) throws ParseException {
        return nominationService.saveNomination( nomination );
    }

    // Save list of nominations uploaded via excel
    @PostMapping("/saveExcelNomination")
    public List<Nomination> saveNomination(@RequestParam("file") MultipartFile excelDatafile, @RequestParam("REWARD_TYPE") final String rewardType) throws ParseException, IOException {
        return nominationService.saveExcelNomination( excelDatafile, rewardType );
    }

    //to delete
    @DeleteMapping("/deleteById/{ID}")
    public void delete(@PathVariable("ID") final Long id) {
        nominationService.delete( id );
    }

    //To update status
    @PutMapping("/statusUpdate")
    @ResponseStatus(HttpStatus.OK)
    public void statusUpdate(@RequestParam("ID") final Long id, @RequestParam("REWARD_TYPE") final String rewardType, @RequestParam("NOMINATION_STATUS") final String nominationStatus) {
        nominationService.statusUpdate( id, rewardType, nominationStatus );
    }
}
