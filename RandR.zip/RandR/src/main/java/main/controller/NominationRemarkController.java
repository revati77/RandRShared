package main.controller;

import main.bean.NominationRemark;
import main.service.NominationRemarkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/nominationRemark")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class NominationRemarkController {

    @Autowired
    private NominationRemarkService nominationRemarkService;

    //  to save
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.OK)
    public NominationRemark createEmployee(@Valid @RequestBody NominationRemark nominationRemark) {
        return nominationRemarkService.save( nominationRemark );
    }

    // to retrieve all details
    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<NominationRemark> getAll() {
        return nominationRemarkService.findAll();
    }

    // to retrieve by id
    @GetMapping("/getById/{ID}")
    @ResponseStatus(HttpStatus.OK)
    public Optional<NominationRemark> getId(@PathVariable("ID") final Long ID) {
        return nominationRemarkService.getId( ID );
    }

    //  to update
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.OK)
    public NominationRemark update(@RequestBody NominationRemark nominationRemark) {
        return nominationRemarkService.update( nominationRemark );
    }
}
