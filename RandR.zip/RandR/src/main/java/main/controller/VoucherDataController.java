package main.controller;

import main.bean.VoucherData;
import main.service.VoucherDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileOutputStream;
import java.util.List;

@RestController
@RequestMapping("/voucherData")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class VoucherDataController {

    @Autowired
    private VoucherDataService voucherDataService;

    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<VoucherData> getAll() {
        return voucherDataService.getAll();
    }

    @GetMapping("/getQuarterlyReward")
    @ResponseStatus(HttpStatus.OK)
    public List<VoucherData> getQuarterlyReward(@RequestParam("quarter") String quarter, @RequestParam("year")Integer year) {
        return voucherDataService.getQuarterlyReward(quarter, year);
    }

    @GetMapping("/downloadQuarterlyVoucher/{quarter}/{year}")
    @ResponseStatus(HttpStatus.OK)
    public FileOutputStream downloadQuarterlyVoucher(@PathVariable("quarter") String quarter, @PathVariable("year")Integer year) {
        return voucherDataService.downloadQuarterlyVoucher(quarter, year);
    }
}
