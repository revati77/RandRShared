package main.controller;

import main.bean.Nomination;
import main.bean.VoucherData;
import main.service.VoucherDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.util.List;

@RestController
@RequestMapping("/voucherData")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class VoucherDataController {

    @Autowired
    private VoucherDataService voucherDataService;

    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<VoucherData> getAll() {
        return voucherDataService.getAll();
    }

    @GetMapping("/getQuarterlyNomination")
    @ResponseStatus(HttpStatus.OK)
    public List<VoucherData> getQuarterlyNomination(@RequestParam("QUARTER") String quarter, @RequestParam("YEAR")Integer year) {
        return voucherDataService.getQuarterlyNomination(quarter, year);
    }

    @GetMapping("/getQuarterlyReward")
    @ResponseStatus(HttpStatus.OK)
    public List<VoucherData> getQuarterlyReward(@RequestParam("QUARTER") String quarter, @RequestParam("YEAR")Integer year) {
        return voucherDataService.getQuarterlyReward(quarter, year);
    }

    @PostMapping("/processQuarterlyNomination/{QUARTER}/{YEAR}")
    @ResponseStatus(HttpStatus.OK)
    public List<VoucherData> processQuarterlyNomination(@Valid @RequestBody List<VoucherData> voucherData, @PathVariable("QUARTER") String quarter, @PathVariable("YEAR")Integer year) throws ParseException {
        return voucherDataService.processQuarterlyNomination(voucherData, quarter, year);
    }

    @PostMapping("/processQuarterlyReward/{QUARTER}/{YEAR}")
    @ResponseStatus(HttpStatus.OK)
    public List<VoucherData> processQuarterlyReward(@Valid @RequestBody List<VoucherData> voucherData, @PathVariable("QUARTER") String quarter, @PathVariable("YEAR")Integer year) throws ParseException {
        return voucherDataService.processQuarterlyReward(voucherData,quarter,year);
    }


/*    @GetMapping(value="/downloadQuarterlyVoucher/{QUARTER}/{YEAR}", produces = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    @ResponseStatus(HttpStatus.OK)
    public byte[] downloadQuarterlyVoucher(@PathVariable("QUARTER") String quarter, @PathVariable("YEAR")Integer year) {
        byte[] res = voucherDataService.downloadQuarterlyVoucher(quarter, year);
        return res;

        // return voucherDataService.downloadQuarterlyVoucher(quarter, year);
    }*/

}
