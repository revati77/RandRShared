package main.reports;

import main.bean.EmployeeCompOff;
import main.repository.EmployeeCompOffRepository;
import main.util.CompOffDate;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class CompOffExceptionDownload {

    @Autowired
    private CompOffDate compOffDate;

    @Autowired
    private EmployeeCompOffRepository employeeCompOffRepository;

    //to retrieve nomination for that quarter who are approved
    public XSSFWorkbook compOffExceptionDownload(String month, Integer year) {

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet( "CompOffExceptionData" );
        XSSFRow row = null;
        row = sheet.createRow( 0 );

        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor( IndexedColors.AQUA.getIndex() );

        Cell cell = row.createCell( 0 );
        cell.setCellValue( "Employee ID" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 1 );
        cell.setCellValue( "Employee Name" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 2 );
        cell.setCellValue( "Compoff Status" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 3 );
        cell.setCellValue( "Absense Type" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 4 );
        cell.setCellValue( "Start Date" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 5 );
        cell.setCellValue( "End Date" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 6 );
        cell.setCellValue( "Lob" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 7 );
        cell.setCellValue( "Project Id" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 8);
        cell.setCellValue( "Project Name" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 9);
        cell.setCellValue( "Location" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 10 );
        cell.setCellValue( "Delivery Manager" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 11 );
        cell.setCellValue( "Part Of Weeekend Interview" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 12 );
        cell.setCellValue( "Quarterly Voucher Status" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 13 );
        cell.setCellValue( "Date Of Interview/Work" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 14);
        cell.setCellValue( "Reason" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 15);
        cell.setCellValue( "Comments" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 16);
        cell.setCellValue( "Exception" );
        cell.setCellStyle( headerCellStyle );

        List<Date> dates = compOffDate.getCurrentMonthList( month,year );

        List<EmployeeCompOff> employeeCompOffList = employeeCompOffRepository.downloadCompoffException("Yes",dates.get( 0 ),dates.get( 1 ));
        int rownum = 1;
        for (EmployeeCompOff employeeCompOff : employeeCompOffList) {
            row = sheet.createRow( rownum++ );
            createList( workbook, employeeCompOff, row );
        }
        return workbook;
    }

    private static void createList(XSSFWorkbook workbook, EmployeeCompOff employeeCompOff, XSSFRow row) // creating cells for each row
    {
        Cell cell = row.createCell( 0 );
        cell.setCellValue( employeeCompOff.getEmpId() );

        cell = row.createCell( 1 );
        cell.setCellValue( employeeCompOff.getEmpName() );

        cell = row.createCell( 2 );
        cell.setCellValue( employeeCompOff.getCompOffStatus() );

        cell = row.createCell( 3 );
        cell.setCellValue( employeeCompOff.getAbsenseType() );

        CreationHelper creationHelper = workbook.getCreationHelper();
        CellStyle style1 = workbook.createCellStyle();
        style1.setDataFormat( creationHelper.createDataFormat().getFormat( "yyyy-MM-dd" ) );


        cell = row.createCell( 4 );
        cell.setCellValue( employeeCompOff.getStartDate());
        cell.setCellStyle( style1 );

        cell = row.createCell( 5 );
        cell.setCellValue( employeeCompOff.getEndDate() );
        cell.setCellStyle( style1 );

        cell = row.createCell( 6 );
        cell.setCellValue( employeeCompOff.getLob() );

        cell = row.createCell( 7 );
        cell.setCellValue( employeeCompOff.getProjectId() );

        cell = row.createCell( 8 );
        cell.setCellValue( employeeCompOff.getProjectName() );

        cell = row.createCell( 9 );
        cell.setCellValue( employeeCompOff.getLocation() );

        cell = row.createCell( 10 );
        cell.setCellValue( employeeCompOff.getDeliveryManager());

        cell = row.createCell( 11);
        cell.setCellValue( employeeCompOff.getPartOfWeeekendInterview() );

        cell = row.createCell( 12);
        cell.setCellValue( employeeCompOff.getQuarterlyVoucherStatus() );

        cell = row.createCell( 13 );
        cell.setCellValue( employeeCompOff.getDateOfInterviewWork());
        cell.setCellStyle( style1 );

        cell = row.createCell( 14 );
        cell.setCellValue( employeeCompOff.getReason());
        cell.setCellStyle( style1 );

        cell = row.createCell( 15);
        cell.setCellValue( employeeCompOff.getComments() );

        cell = row.createCell( 16);
        cell.setCellValue( employeeCompOff.getException() );


    }
}
