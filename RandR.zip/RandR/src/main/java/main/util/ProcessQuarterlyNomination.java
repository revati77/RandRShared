package main.util;

import main.bean.Nomination;
import main.bean.VoucherData;
import main.repository.NominationRepository;
import main.repository.VoucherDataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class ProcessQuarterlyNomination {

    @Autowired
    private NominationRepository nominationRepository;
    @Autowired
    private VoucherDataRepository voucherDataRepository;

    public List<VoucherData> processQuarterlyNomination(List<VoucherData> voucherDataList, String quarter, Integer year) throws ParseException {

        // Insert to VoucherData Table
        Date date=FormatDate.getCurrentDate();
        voucherDataList.stream().forEach( empVoucher -> empVoucher.setAllotedDate(date ) ) ;
        voucherDataRepository.saveAll( voucherDataList );

        // Update status in nomination table to VoucherAlloted
        List<Nomination> nominationList = new ArrayList<>();
        voucherDataList.stream().forEach( empVoucher -> nominationList.add(new Nomination(empVoucher.getEmpName(),empVoucher.getEmpId(),empVoucher.getTerm(),empVoucher.getRewardType())));
        nominationList.stream().forEach( nomination -> nomination.setNominationStatus( "VoucherAlloted" ));

        for(Nomination nomination: nominationList){
            nominationRepository.updateVoucherStatus(nomination.getNomineeId(),nomination.getTerm(),nomination.getRewardType(),"VoucherAlloted");
        }

        return voucherDataList;
    }

}
