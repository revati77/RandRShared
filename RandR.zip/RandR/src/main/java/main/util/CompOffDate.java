package main.util;

import main.bean.EmployeeReward;
import main.repository.EmployeeRewardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class CompOffDate {

    @Autowired
    private EmployeeRewardRepository employeeRewardRepository;

/*    public List<EmployeeReward> retrieveByDate(Integer empId, Date date1) {
        Calendar c = Calendar.getInstance();
        c.setTime( date1 );
        c.add( Calendar.MONTH, -3 );
        Date date2 = c.getTime();
        System.out.print( date1 );
        System.out.print( date2 );
        return employeeRewardRepository.toGetByQuarterDate( empId, date1, date2 );
    }*/

    public List<Date>  getQuarterList(String quarter, Integer year) {

        List<Date> dates= new ArrayList<>(  );

        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        c1.set( Calendar.YEAR, year );
        c2.set( Calendar.YEAR, year );

        if (quarter.equals( "Q1" )) {
            c1.set( Calendar.MONTH, 3 );
            c2.set( Calendar.MONTH, 5 );
            c1.set( Calendar.DAY_OF_MONTH, 1 );
            c2.set( Calendar.DAY_OF_MONTH, 30 );
        }

        if (quarter.equals( "Q2" )) {
            c1.set( Calendar.MONTH, 6 );
            c2.set( Calendar.MONTH, 8 );
            c1.set( Calendar.DAY_OF_MONTH, 1 );
            c2.set( Calendar.DAY_OF_MONTH, 30 );
        }

        if (quarter.equals( "Q3" )) {
            c1.set( Calendar.MONTH, 9 );
            c2.set( Calendar.MONTH, 11 );
            c1.set( Calendar.DAY_OF_MONTH, 1 );
            c2.set( Calendar.DAY_OF_MONTH, 31 );
        }

        if (quarter.equals( "Q4" )) {
            c1.set( Calendar.MONTH, 0 );
            c2.set( Calendar.MONTH, 2 );
            c1.set( Calendar.DAY_OF_MONTH, 1 );
            c2.set( Calendar.DAY_OF_MONTH, 31 );
        }

        Date date1 = c1.getTime();
        Date date2 = c2.getTime();
        dates.add( date1 );
        dates.add( date2 );
        return dates;
    }

}