package main.util;

import main.bean.EmployeeReward;
import main.repository.EmployeeRewardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class CompOffDate {

    @Autowired
    private EmployeeRewardRepository employeeRewardRepository;

/*    public List<EmployeeReward> retrieveByDate(Integer empId, Date date1) {
        Calendar c = Calendar.getInstance();
        c.setTime( date1 );
        c.add( Calendar.MONTH, -3 );
        Date date2 = c.getTime();
        System.out.print( date1 );
        System.out.print( date2 );
        return employeeRewardRepository.toGetByQuarterDate( empId, date1, date2 );
    }*/

    public List<Date> getQuarterList(String quarter, Integer year) {

        List<Date> dates = new ArrayList<>();

        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        c1.set( Calendar.YEAR, year );
        c2.set( Calendar.YEAR, year );

        if (quarter.equals( "Q1" )) {
            c1.set( Calendar.MONTH, 3 );
            c2.set( Calendar.MONTH, 5 );
            c1.set( Calendar.DAY_OF_MONTH, 1 );
            c2.set( Calendar.DAY_OF_MONTH, 30 );
        }

        if (quarter.equals( "Q2" )) {
            c1.set( Calendar.MONTH, 6 );
            c2.set( Calendar.MONTH, 8 );
            c1.set( Calendar.DAY_OF_MONTH, 1 );
            c2.set( Calendar.DAY_OF_MONTH, 30 );
        }

        if (quarter.equals( "Q3" )) {
            c1.set( Calendar.MONTH, 9 );
            c2.set( Calendar.MONTH, 11 );
            c1.set( Calendar.DAY_OF_MONTH, 1 );
            c2.set( Calendar.DAY_OF_MONTH, 31 );
        }

        if (quarter.equals( "Q4" )) {
            c1.set( Calendar.MONTH, 0 );
            c2.set( Calendar.MONTH, 2 );
            c1.set( Calendar.DAY_OF_MONTH, 1 );
            c2.set( Calendar.DAY_OF_MONTH, 31 );
        }

        Date date1 = c1.getTime();
        Date date2 = c2.getTime();
        dates.add( date1 );
        dates.add( date2 );
        return dates;
    }

    public List<Date> getMonthList(String month, Integer year) {

        List<Date> dates= new ArrayList<>(  );
        //For calculate startDate
        Calendar c = Calendar.getInstance();
        c.set( Calendar.YEAR, year );
        c.set( Calendar.DAY_OF_MONTH, 1 );
        //For calculate endDate
        Calendar c1 = Calendar.getInstance();
        c1.set( Calendar.YEAR, year );
        c1.set( Calendar.DAY_OF_MONTH, 1 );
        //To set the month
        switch (month)
        {
            case "January":
                c.set( Calendar.MONTH,1 );
                c1.set( Calendar.MONTH,1 );
                break;
            case "February":
                c.set( Calendar.MONTH,2 );
                c1.set( Calendar.MONTH,2 );
                break;
            case "March":
                c.set( Calendar.MONTH,3 );
                c1.set( Calendar.MONTH,3 );
                break;
            case "April":
                c.set( Calendar.MONTH,4 );
                c1.set( Calendar.MONTH,4 );
                break;
            case "May":
                c.set( Calendar.MONTH,5 );
                c1.set( Calendar.MONTH,5 );
                break;
            case "June":
                c.set( Calendar.MONTH,6 );
                c1.set( Calendar.MONTH,6 );
                break;
            case "July":
                c.set( Calendar.MONTH,7 );
                c1.set( Calendar.MONTH,7 );
                break;
            case "August":
                c.set( Calendar.MONTH,8 );
                c1.set( Calendar.MONTH,8 );
                break;
            case "September":
                c.set( Calendar.MONTH,9 );
                c1.set( Calendar.MONTH,9 );
                break;
            case "October":
                c.set( Calendar.MONTH,10 );
                c1.set( Calendar.MONTH,10 );
                break;
            case "November":
                c.set( Calendar.MONTH,11 );
                c1.set( Calendar.MONTH,11 );
                break;
            case "December":
                c.set( Calendar.MONTH,0 );
                c1.set( Calendar.MONTH,0 );
                break;
        }
        c.add(Calendar.MONTH, -3);
        Date startDate=c.getTime();
        c1.add(Calendar.DATE,-1);
        Date endDate=c1.getTime();
        dates.add( startDate );
        dates.add( endDate );
        System.out.println(dates);
        return dates;
    }
}