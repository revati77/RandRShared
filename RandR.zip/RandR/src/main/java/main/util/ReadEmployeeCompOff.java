package main.util;

import main.bean.EmployeeCompOff;
import main.bean.EmployeeReward;
import main.repository.EmployeeRewardRepository;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

@Component
public class ReadEmployeeCompOff {

    @Autowired
    private EmployeeRewardRepository employeeRewardRepository;

    public List<EmployeeCompOff> readCompOff(MultipartFile compOffFile) throws IOException, ParseException {

        XSSFWorkbook xssfWorkbook = new XSSFWorkbook( compOffFile.getInputStream() );
        XSSFSheet xssfSheet = xssfWorkbook.getSheet( "CompOff" );
        Iterator iterator = xssfSheet.iterator();

        List<EmployeeCompOff> employeeCompOffList = new ArrayList<>();

        while (iterator.hasNext()) {
            Row row = (Row) iterator.next();
            if (row.getRowNum() == 0) continue; //just skip the rows if row number is 0

            EmployeeCompOff compOffData = new EmployeeCompOff();
            int empId = (int) (row.getCell( 0 ).getNumericCellValue());
            compOffData.setEmpId( empId );
            compOffData.setEmpName( row.getCell( 1 ).getStringCellValue() );
            compOffData.setCompOffStatus( row.getCell( 2 ).getStringCellValue() );
            compOffData.setAbsenseType( row.getCell( 3 ).getStringCellValue() );
            compOffData.setStartDate( FormatDate.formateDate( row.getCell( 4 ).getStringCellValue() ) );
            compOffData.setEndDate( FormatDate.formateDate( row.getCell( 5 ).getStringCellValue() ) );

            employeeCompOffList.add( compOffData );
        }
        return employeeCompOffList;
    }
}
