package main.util;

import main.bean.EmployeeProjectInfo;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Component
public class ReadEmployeeProjectDetails {

    public List<EmployeeProjectInfo> readEmployeeProjectDetails(MultipartFile employeeProjectExcel) throws IOException {

        XSSFWorkbook xssfWorkbook = new XSSFWorkbook( employeeProjectExcel.getInputStream() );
        XSSFSheet xssfSheet = xssfWorkbook.getSheet( "EmployeeProjectInfo" );
        Iterator iterator = xssfSheet.iterator();

        List<EmployeeProjectInfo> employeeProjectInfoList = new ArrayList<>();

        while (iterator.hasNext()) {
            Row row = (Row) iterator.next();
            if (row.getRowNum() == 0) continue; //just skip the rows if row number is 0
            EmployeeProjectInfo employeeProjectInfo = new EmployeeProjectInfo();

            int empId = (int) (row.getCell( 0 ).getNumericCellValue());
            employeeProjectInfo.setEmpId( empId );
            employeeProjectInfo.setLob( row.getCell( 1 ).getStringCellValue() );
            employeeProjectInfo.setProjectId( (int) row.getCell( 2 ).getNumericCellValue() );
            employeeProjectInfo.setProjectName( row.getCell( 3 ).getStringCellValue() );
            employeeProjectInfo.setLocation( row.getCell( 4 ).getStringCellValue() );
            employeeProjectInfo.setDeliveryManager( row.getCell( 5 ).getStringCellValue() );

            employeeProjectInfoList.add( employeeProjectInfo );
        }
        return employeeProjectInfoList;
    }
}
