package main.util;

import main.bean.EmployeeRewards;
import main.repository.EmployeeRewardsRepository;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Component

public class WeekendExcelReader {

    /*  public static void main(String[] args) throws IOException {
           ExcelReader excelReader = new ExcelReader();
           excelReader.read();
       }
     */

    @Autowired
    EmployeeRewardsRepository employeeRewardsRepository;

    @Autowired
    CalculatePoints calculatePoints;

    public List<EmployeeRewards> read(MultipartFile file, Integer empId) throws IOException, ParseException {

        XSSFWorkbook xssfWorkbook = new XSSFWorkbook(file.getInputStream());

        // XSSFWorkbook xssfWorkbook = new XSSFWorkbook( new FileInputStream( new File( "C:\\Users\\rashmi.n\\RandR\\Excel\\sample.xlsx" ) ) );
        // XSSFWorkbook xssfWorkbook = new XSSFWorkbook(new FileInputStream(new File("C:\\CodeBase\\Rashu\\Employees.xlsx")));
        XSSFSheet xssfSheet = xssfWorkbook.getSheet("employee");
        Iterator iterator = xssfSheet.iterator();
        //HSSFWorkbook hssfWorkbook = new HSSFWorkbook(new FileInputStream(new File("C:\\Users\\rashmi.n\\RandR\\sample.xlsx")));
        //HSSFSheet hssfSheet = hssfWorkbook.getSheet("employee");
        //Iterator iterator = hssfSheet.iterator();

        List<EmployeeRewards> employeeEntities = new ArrayList<>();

        while (iterator.hasNext()) {

            Row row = (Row) iterator.next();

            if (row.getRowNum() == 0) continue; //just skip the rows if row number is 0

            EmployeeRewards employeeRewards = new EmployeeRewards();

            employeeRewards.setEmpId((int) row.getCell(0).getNumericCellValue());
            employeeRewards.setEmpName(row.getCell(1).getStringCellValue());
            employeeRewards.setRewardType(row.getCell(2).getStringCellValue());
            employeeRewards.setSkill(row.getCell(3).getStringCellValue());
            employeeRewards.setLocation(row.getCell(4).getStringCellValue());
            int noOfInterviews = new Double(row.getCell(5).getNumericCellValue()).intValue();
            employeeRewards.setNoOfInterviews(noOfInterviews);

            String date_of = row.getCell(6).getStringCellValue();
            DateTimeFormatter simpleDateFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            DateTimeFormatter simpleDateFormat1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            employeeRewards.setDateOf(LocalDate.parse(date_of, simpleDateFormat).format(simpleDateFormat1));

            int managerId = new Double(row.getCell(7).getNumericCellValue()).intValue();
            employeeRewards.setManagerId(managerId);

            Integer points = calculatePoints.calculateTotalPoints(employeeRewards.getRewardType(), employeeRewards.getNoOfInterviews());
            employeeRewards.setNoOfPoints(points);
            employeeRewards.setCreatedby(empId);
            employeeRewards.setModifiedBy(empId);
            employeeRewards.setAdvanceCompoff("No");
            employeeRewards.setStatus("Pending");
            employeeRewards.setEligibleForCompoff("Yes");

            employeeEntities.add(employeeRewards);
        }
        employeeRewardsRepository.saveAll(employeeEntities);
        return employeeEntities;
    }

}
