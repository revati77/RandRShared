package main.util;

import main.bean.VoucherData;
import main.repository.VoucherDataRepository;
import main.service.VoucherDataService;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

@Component
public class VoucherDataDownload {

    @Autowired
    private VoucherDataService voucherDataService;

    public XSSFWorkbook voucherDataDownload(String quarter, Integer year) {

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet( "VoucherData" );
        XSSFRow row = null;
        row = sheet.createRow( 0 );

        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor( IndexedColors.AQUA.getIndex() );
        Cell cell = row.createCell( 0 );
        cell.setCellValue( "Employee ID" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 1 );
        cell.setCellValue( "Employee Name" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 2 );
        cell.setCellValue( "Points" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 3 );
        cell.setCellValue( "Quarter" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 4 );
        cell.setCellValue( "Year" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 5 );
        cell.setCellValue( "AllotedDate" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 6 );
        cell.setCellValue( "RewardType" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 7 );
        cell.setCellValue( "Term" );
        cell.setCellStyle( headerCellStyle );

        List<VoucherData> voucherDataList = voucherDataService.getQuarterlyData( quarter, year );
        int rownum = 1;
        for (VoucherData voucherData : voucherDataList) {
            row = sheet.createRow( rownum++ );
            createList( workbook, voucherData, row );
        }
          return workbook;
    }

    private static void createList(XSSFWorkbook workbook, VoucherData voucherData, XSSFRow row) // creating cells for each row
    {
        Cell cell = row.createCell( 0 );
        cell.setCellValue( voucherData.getEmpId() );

        cell = row.createCell( 1 );
        cell.setCellValue( voucherData.getEmpName() );

        cell = row.createCell( 2 );
        cell.setCellValue( voucherData.getPoints() );

        cell = row.createCell( 3 );
        cell.setCellValue( voucherData.getQuarter() );

        cell = row.createCell( 4 );
        cell.setCellValue( voucherData.getYear() );
        cell = row.createCell( 5 );
        cell.setCellValue( voucherData.getAllotedDate() );
        cell = row.createCell( 6 );
        cell.setCellValue( voucherData.getRewardType() );
        cell = row.createCell( 7 );
        cell.setCellValue( voucherData.getTerm() );

        CreationHelper creationHelper = workbook.getCreationHelper();
        CellStyle style1 = workbook.createCellStyle();
        style1.setDataFormat( creationHelper.createDataFormat().getFormat(
                "yyyy-MM-dd" ) );
        cell.setCellStyle( style1 );
    }
}

