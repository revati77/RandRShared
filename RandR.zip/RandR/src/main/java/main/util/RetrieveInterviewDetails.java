package main.util;

public class RetrieveInterviewDetails {
}
