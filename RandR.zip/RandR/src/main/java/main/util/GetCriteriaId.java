package main.util;

import main.bean.NominationCriteria;
import main.service.NominationCriteriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;

@Component
public class GetCriteriaId {

    private static List<NominationCriteria> nominationCriteriaList;
    @Autowired
    private NominationCriteriaService nominationCriteriaService;

    private void getAllCriteria(String rewardType) {
        nominationCriteriaList  = nominationCriteriaService.getId(rewardType);
    }

    public Integer getCriteriaId(String criteria, String rewardType) {
        Integer criteriaId = null;
        if (CollectionUtils.isEmpty(nominationCriteriaList)) {
            getAllCriteria(rewardType);
        }
        Optional<NominationCriteria> nominationCriteria = nominationCriteriaList.stream().filter( nominationCriteriaData -> nominationCriteriaData.getCriteria().equals(criteria)).findFirst();
        if (nominationCriteria.isPresent()) {
            criteriaId = nominationCriteria.get().getCriteriaId();
        }
        return criteriaId;
    }

}
