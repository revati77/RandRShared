package main.util;

import main.bean.EmployeeReward;
import main.bean.Nomination;
import main.repository.EmployeeRewardRepository;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class WeekendDetailsDownload {
    @Autowired
    private EmployeeRewardRepository employeeRewardRepository;

    //  to retrieve weekend details between two dates
    public XSSFWorkbook downloadWeekendDetails(Date startDate, Date endDate)
    {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet( "WeekendData" );
        XSSFRow row = null;
        row = sheet.createRow( 0 );

        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor( IndexedColors.AQUA.getIndex() );
        Cell cell = row.createCell( 0 );
        cell.setCellValue( "Employee ID" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 1 );
        cell.setCellValue( "Employee Name" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 2 );
        cell.setCellValue( "Reward Type" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 3 );
        cell.setCellValue( "Skill" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 4 );
        cell.setCellValue( "Location" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 5 );
        cell.setCellValue( "Number Of Interviews" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 6 );
        cell.setCellValue( "Number Of Points" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 7 );
        cell.setCellValue( "Date Of" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 8 );
        cell.setCellValue( "Created By" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 9 );
        cell.setCellValue( "Modified By" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 10 );
        cell.setCellValue( "Manager Id" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 11 );
        cell.setCellValue( "Advance CompOff" );
        cell.setCellStyle( headerCellStyle );

        cell = row.createCell( 12 );
        cell.setCellValue( "Status" );
        cell.setCellStyle( headerCellStyle );

        List<EmployeeReward> employeeRewardList = employeeRewardRepository.downloadWeekendDetails(startDate,endDate);
        int rownum = 1;
        for (EmployeeReward employeeReward : employeeRewardList) {
            row = sheet.createRow( rownum++ );
            createList( workbook, employeeReward, row );
        }
        return workbook;
    }

    private static void createList(XSSFWorkbook workbook, EmployeeReward employeeReward, XSSFRow row) // creating cells for each row
    {
        Cell cell = row.createCell( 0 );
        cell.setCellValue( employeeReward.getEmpId() );

        cell = row.createCell( 1 );
        cell.setCellValue( employeeReward.getEmpName());

        cell = row.createCell( 2 );
        cell.setCellValue( employeeReward.getRewardType() );

        cell = row.createCell( 3 );
        cell.setCellValue( employeeReward.getSkill() );

        cell = row.createCell( 4 );
        cell.setCellValue( employeeReward.getLocation());

        cell = row.createCell( 5 );
        cell.setCellValue( employeeReward.getNoOfInterviews() );

        cell = row.createCell( 6 );
        cell.setCellValue( employeeReward.getNoOfPoints() );

        cell = row.createCell( 7 );
        cell.setCellValue( employeeReward.getDateOf() );
        CreationHelper creationHelper = workbook.getCreationHelper();
        CellStyle style1 = workbook.createCellStyle();
        style1.setDataFormat( creationHelper.createDataFormat().getFormat("yyyy-MM-dd" ) );
        cell.setCellStyle( style1 );

        cell = row.createCell( 8 );
        cell.setCellValue( employeeReward.getCreatedby() );

        cell = row.createCell( 9 );
        cell.setCellValue( employeeReward.getModifiedBy());

        cell = row.createCell( 10 );
        cell.setCellValue( employeeReward.getManagerId() );

        cell = row.createCell( 11 );
        cell.setCellValue( employeeReward.getAdvanceCompoff() );

        cell = row.createCell( 12 );
        cell.setCellValue( employeeReward.getStatus() );
    }


}
