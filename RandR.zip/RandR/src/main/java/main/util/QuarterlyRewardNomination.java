package main.util;

import main.bean.VoucherData;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class QuarterlyRewardNomination {

    public List<VoucherData> quarterlyRewardNomination(String quarter, Integer year){
        List<VoucherData> voucherDataList = null;

        if(quarter.equals( "Q1" )){
          //  String start=year.append("-01-01");
           // Date startDate="01-01"

                    //toGetByQuarterDate();
        }




        return voucherDataList;
    }
}
