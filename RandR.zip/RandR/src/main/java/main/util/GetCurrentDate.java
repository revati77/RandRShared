package main.util;

import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class GetCurrentDate {

    public static Date getCurrentDate() throws ParseException {
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        String myDate = sdf.format(date);
        return sdf.parse(myDate);
    }
}