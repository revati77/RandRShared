package main.util;

import main.bean.NominationRemark;
import main.repository.NominationRemarkRepository;
import org.apache.poi.ss.usermodel.Row;
import main.bean.Nomination;
import main.repository.NominationRepository;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class NominationExcelReader {

    @Autowired
    static NominationRepository nominationRepository;

    @Autowired
    private static NominationRemarkRepository nominationRemarkRepository;

    @Autowired
    private static NominationRemarkReader nominationRemarkReader;

    public static List<Nomination> read(MultipartFile file, String rewardType) throws IOException, ParseException {

        XSSFWorkbook xssfWorkbook = new XSSFWorkbook( file.getInputStream() );
        XSSFSheet xssfSheet = xssfWorkbook.getSheet( "nomination" );
        Iterator iterator = xssfSheet.iterator();

        List<Nomination> nominations = new ArrayList<>();

        while (iterator.hasNext()) {

            Row row = (Row) iterator.next();

            if (row.getRowNum() == 0) continue; //just skip the rows if row number is 0

            Nomination nomination = new Nomination();

            nomination.setNomineeName( row.getCell( 0 ).getStringCellValue() );
            nomination.setNomineeId( (int) row.getCell( 1 ).getNumericCellValue() );
            nomination.setManagerName( row.getCell( 2 ).getStringCellValue() );
            nomination.setManagerId( (int) row.getCell( 3 ).getNumericCellValue() );
            nomination.setNominatorName( row.getCell( 4 ).getStringCellValue() );
            nomination.setNominatorid( (int) row.getCell( 5 ).getNumericCellValue() );
            nomination.setLob( row.getCell( 6 ).getStringCellValue() );
            nomination.setTerm( row.getCell( 7 ).getStringCellValue() );
            nomination.setPmoId( (int) row.getCell( 8 ).getNumericCellValue() );
            nomination.setRewardType( rewardType );
            nomination.setNominationStatus( "Pending" );
            nomination.setNominationDate( GetCurrentDate.getCurrentDate() );

            Nomination nominationParam = nominationRepository.save( nomination );
            Long nominationId = nominationParam.getId();
//            List<NominationRemark> nominationRemarkList = nominationRemarkReader.nominationRemarkReader(file, rewardType);
//            nomination.setNominationRemarkList(nominationRemarkList);

            List<NominationRemark> nominationRemarkList = null;
            NominationRemark nominationRemark = new NominationRemark();
            // Remarks for Client_Appreciation

            for (int i = 0; i == 3; i++) {
                nominationRemark.setRemark( row.getCell( i + 1 ).getStringCellValue() );
                nominationRemark.setId( nominationId );
                nominationRemarkList.add( nominationRemark );
            }
            nominationRemarkList = nominationRemarkRepository.saveAll( nominationRemarkList );
            nominationParam.setNominationRemarkList( nominationRemarkList );

            nominations.add( nomination );
        }
        nominationRepository.saveAll( nominations );
        return nominations;
    }

}
