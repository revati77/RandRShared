package main.util;

import main.bean.EmployeeCompOff;
import main.repository.EmployeeCompOffRepository;
import main.repository.EmployeeRewardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UpdateEmployeeCompOff {

    @Autowired
    private EmployeeRewardRepository employeeRewardRepository;
    @Autowired
    private EmployeeCompOffRepository employeeCompOffRepository;

    public String updateEmployeeCompOff(List<EmployeeCompOff> employeeCompOffList){

        String exceptionStatus=null;
        for (EmployeeCompOff employeeCompOff : employeeCompOffList){
            String status=employeeRewardRepository.getStatus(employeeCompOff.getEmpId(),employeeCompOff.getDateOfInterviewWork());
            if (status.equals( "VoucherAlloted" )){
                employeeCompOff.setQuarterlyVoucherStatus( status );
                employeeCompOff.setException( "Yes" );
                exceptionStatus="Yes";
            }
            else{
                employeeCompOff.setException( "No" );
            }
        }
        employeeCompOffRepository.saveAll(employeeCompOffList);
        return exceptionStatus;
    }
}
