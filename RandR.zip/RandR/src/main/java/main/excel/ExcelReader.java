package main.excel;

import main.beans.EmployeeEntity;
import main.repositories.EmployeeRewardsRepository;
import main.services.CalculatePoints;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Component

public class ExcelReader {

    /*  public static void main(String[] args) throws IOException {
           ExcelReader excelReader = new ExcelReader();
           excelReader.read();
       }
     */

    @Autowired
    EmployeeRewardsRepository employeeRewardsRepository;

    @Autowired
    CalculatePoints calculatePoints;

    public List<EmployeeEntity> read(MultipartFile file) throws IOException, ParseException {

        XSSFWorkbook xssfWorkbook = new XSSFWorkbook( file.getInputStream() );

        // XSSFWorkbook xssfWorkbook = new XSSFWorkbook( new FileInputStream( new File( "C:\\Users\\rashmi.n\\RandR\\Excel\\sample.xlsx" ) ) );
        // XSSFWorkbook xssfWorkbook = new XSSFWorkbook(new FileInputStream(new File("C:\\CodeBase\\Rashu\\Employees.xlsx")));
        XSSFSheet xssfSheet = xssfWorkbook.getSheet( "employee" );
        Iterator iterator = xssfSheet.iterator();
        //HSSFWorkbook hssfWorkbook = new HSSFWorkbook(new FileInputStream(new File("C:\\Users\\rashmi.n\\RandR\\sample.xlsx")));
        //HSSFSheet hssfSheet = hssfWorkbook.getSheet("employee");
        //Iterator iterator = hssfSheet.iterator();

        List<EmployeeEntity> employeeEntities = new ArrayList<>();

        while (iterator.hasNext()) {

            Row row = (Row) iterator.next();

            if (row.getRowNum() == 0) continue; //just skip the rows if row number is 0

            EmployeeEntity employeeEntity = new EmployeeEntity();

            employeeEntity.setEmpId( (int) row.getCell( 0 ).getNumericCellValue() );
            employeeEntity.setEmpName( row.getCell( 1 ).getStringCellValue() );
            employeeEntity.setRewardType( row.getCell( 2 ).getStringCellValue() );
            int noOfInterviews = new Double( row.getCell( 3 ).getNumericCellValue() ).intValue();
            employeeEntity.setNoOfInterviews( noOfInterviews );

            String date_of = row.getCell( 4 ).getStringCellValue();
            DateTimeFormatter simpleDateFormat = DateTimeFormatter.ofPattern( "dd-MM-yyyy" );
            DateTimeFormatter simpleDateFormat1 = DateTimeFormatter.ofPattern( "yyyy-MM-dd" );
            employeeEntity.setDateOf( LocalDate.parse( date_of, simpleDateFormat ).format( simpleDateFormat1 ) );

            int managerId = new Double( row.getCell( 5 ).getNumericCellValue() ).intValue();
            employeeEntity.setManagerId( managerId );

            Integer points = calculatePoints.CalculateTotalPoints( employeeEntity.getRewardType(), employeeEntity.getNoOfInterviews() );
            employeeEntity.setNoOfPoints( points );

            employeeRewardsRepository.save( employeeEntity );
            employeeEntities.add( employeeEntity );
        }
        return employeeEntities;
    }

}
