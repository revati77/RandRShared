package main.beans;

import javax.persistence.*;


@Entity
@Table(name = "nominationcriteria")
public class NominationCriteria {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer CRITERIA_ID;
    private String REWARD_TYPE;
    private String CRITERIA;


    public Integer getCRITERIA_ID() {
        return CRITERIA_ID;
    }

    public void setCRITERIA_ID(Integer CRITERIA_ID) {
        this.CRITERIA_ID = CRITERIA_ID;
    }

    public String getREWARD_TYPE() {
        return REWARD_TYPE;
    }

    public void setREWARD_TYPE(String REWARD_TYPE) {
        this.REWARD_TYPE = REWARD_TYPE;
    }

    public String getCRITERIA() {
        return CRITERIA;
    }

    public void setCRITERIA(String CRITERIA) {
        this.CRITERIA = CRITERIA;
    }
}
