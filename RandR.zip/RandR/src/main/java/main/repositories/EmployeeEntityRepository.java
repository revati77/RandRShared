package main.repositories;

import main.beans.EmployeeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeEntityRepository extends JpaRepository<EmployeeEntity,Integer> {

    @Query(value = "select ELIGIBLE_FOR_COMPOFF from employeerewards e where e.EMP_ID = ?1 and e.REWARD_TYPE = ?2 and e.DATE_OF = ?3", nativeQuery = true)
    String findBYParameters (@Param("empid") Integer EMP_ID, @Param("rewardtype") String REWARD_TYPE, @Param("dateof") String DATE_OF);
//     List<EmployeeEntity> findBYParameters(Integer EMP_ID, String REWARD_TYPE, String DATE_OF);


}
