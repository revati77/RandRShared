package main.repositories;


import main.beans.EmployeeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRewardsRepository extends JpaRepository<EmployeeEntity, Long> {
    @Query("select e from EmployeeEntity e where e.empId=?1")
    List<EmployeeEntity> findByEmpId(Integer EMP_ID);

    @Query("select e from EmployeeEntity e where e.managerId=?1")
    List<EmployeeEntity> findByManagerId(Integer MANAGER_ID);
}
