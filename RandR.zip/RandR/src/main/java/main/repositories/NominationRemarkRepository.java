package main.repositories;

import main.beans.NominationRemark;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NominationRemarkRepository extends JpaRepository<NominationRemark,Long> {
}
