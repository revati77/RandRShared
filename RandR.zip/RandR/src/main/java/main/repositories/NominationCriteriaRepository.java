package main.repositories;

import main.beans.NominationCriteria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NominationCriteriaRepository extends JpaRepository<NominationCriteria,Integer> {
    @Query("select r from NominationCriteria r where r.REWARD_TYPE=?1")
    List<NominationCriteria> findByRewardType(String reward_type);
 }
