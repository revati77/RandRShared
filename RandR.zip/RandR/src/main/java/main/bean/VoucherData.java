package main.bean;

import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name = "voucherdata")
public class VoucherData {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "VOUCHER_ID")
    private Long voucherId;
    @Column(name = "EMP_ID ")
    private Integer empId;
    @Column(name = "EMP_NAME")
    private String empName;
    @Column(name = "POINTS")
    private Integer points;
    @Column(name = "ALLOTED_DATE")
    private Date allotedDate;
    @Column(name = "QUARTER")
    private String quarter;
    @Column(name = "YEAR")
    private Integer year;

    public Long getVoucherId() {
        return voucherId;
    }

    public Integer getEmpId() {
        return empId;
    }

    public void setEmpId(Integer empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public Date getAllotedDate() {
        return allotedDate;
    }

    public void setAllotedDate(Date allotedDate) {
        this.allotedDate = allotedDate;
    }

    public String getQuarter() {
        return quarter;
    }

    public void setQuarter(String quarter) {
        this.quarter = quarter;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }
}
