package main.bean;
import org.springframework.stereotype.Component;
import javax.persistence.*;
@Entity
@Table(name = "employeecompoff")
public class EmployeeCompOff {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "COMPOFF_ID")
    private Long compOffId;
    @Column(name = "EMP_ID ")
    private Integer empId;
    @Column(name = "EMP_NAME")
    private String empName;
    @Column(name = "COMPOFF_STATUS")
    private String compOffStatus;
    @Column(name = "ABSENCE_TYPE")
    private String absenseType;
    @Column(name = "START_DATE ")
    private Integer startDate;
    @Column(name = "END_DATE ")
    private Integer endDate;
    @Column(name = "OFF_DAY ")
    private Integer offDay;
    @Column(name = "LOB")
    private String lob;
    @Column(name = "PROJECT_ID ")
    private int projectId;
    @Column(name = "PROJECT_NAME")
    private String projectName;
    @Column(name = "LOCATION")
    private String location;
    @Column(name = "DELIVERY_MANAGER")
    private String DeliveryManager;
    @Column(name = "ADVANCE_COMPOFF")
    private String advanceCompOff;
    @Column(name = "VOUCHER_STATUS")
    private String voucherStatus;
    @Column(name = "PART_OF_WEEKEND_INTERVIEW")
    private String partOfWeeekendInterview;
    @Column(name = "REASON")
    private String reason;
    @Column(name="COMMENTS")
    private String comments;
    public EmployeeCompOff() {
    }
    public Long getCompOffId() {
        return compOffId;
    }
    public void setCompOffId(Long compOffId) {
        this.compOffId = compOffId;
    }
    public Integer getEmpId() {
        return empId;
    }
    public void setEmpId(Integer empId) {
        this.empId = empId;
    }
    public String getEmpName() {
        return empName;
    }
    public void setEmpName(String empName) {
        this.empName = empName;
    }
    public String getCompOffStatus() {
        return compOffStatus;
    }
    public void setCompOffStatus(String compOffStatus) {
        this.compOffStatus = compOffStatus;
    }
    public String getAbsenseType() {
        return absenseType;
    }
    public void setAbsenseType(String absenseType) {
        this.absenseType = absenseType;
    }
    public Integer getStartDate() {
        return startDate;
    }
    public void setStartDate(Integer startDate) {
        this.startDate = startDate;
    }
    public Integer getEndDate() {
        return endDate;
    }
    public void setEndDate(Integer endDate) {
        this.endDate = endDate;
    }
    public Integer getOffDay() {
        return offDay;
    }
    public void setOffDay(Integer offDay) {
        this.offDay = offDay;
    }
    public String getLob() {
        return lob;
    }
    public void setLob(String lob) {
        this.lob = lob;
    }
    public int getProjectId() {
        return projectId;
    }
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
    public String getProjectName() {
        return projectName;
    }
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }
    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }
    public String getDeliveryManager() {
        return DeliveryManager;
    }
    public void setDeliveryManager(String deliveryManager) {
        DeliveryManager = deliveryManager;
    }
    public String getAdvanceCompOff() {
        return advanceCompOff;
    }
    public void setAdvanceCompOff(String advanceCompOff) {
        this.advanceCompOff = advanceCompOff;
    }
    public String getVoucherStatus() {
        return voucherStatus;
    }
    public void setVoucherStatus(String voucherStatus) {
        this.voucherStatus = voucherStatus;
    }
    public String getPartOfWeeekendInterview() {
        return partOfWeeekendInterview;
    }
    public void setPartOfWeeekendInterview(String partOfWeeekendInterview) {
        this.partOfWeeekendInterview = partOfWeeekendInterview;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}