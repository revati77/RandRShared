package main.bean;

import javax.persistence.*;

@Entity
@Table(name = "employeerole")

public class EmployeeRole {

    @Id
    @Column(name = "EMP_ID")
    private Integer empId;

    @Column(name = "EMP_NAME")
    private String empName;
    @Column(name = "EMP_ROLE")
    private String empRole;

    @Column(name = "MANAGER_ID")
    private Long managerId;

    @Column(name = "PASSWORD")
    private String password;

    @Column(name="LOB")
    private String lob;

    @Column(name="PROJECT_ID")
    private int projectId;

    @Column(name="PROJECT_NAME")
    private String projectName;

    @Column(name="LOCATION")
    private String location;

    @Column(name="DELIVERY_MANAGER")
    private String DeliveryManager;

    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDeliveryManager() {
        return DeliveryManager;
    }

    public void setDeliveryManager(String deliveryManager) {
        DeliveryManager = deliveryManager;
    }

    public Integer getEmpId() {
        return empId;
    }

    public void setEmpId(Integer empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpRole() {
        return empRole;
    }

    public void setEmpRole(String empRole) {
        this.empRole = empRole;
    }

    public Long getManagerId() {
        return managerId;
    }

    public void setManagerId(Long managerId) {
        this.managerId = managerId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

        @Override
    public String toString() {
        return "EmployeeRole [Employee Id= " + empId + ",Employee Name= " + empName + ",Employee Role= " + empRole + ",Manager Id= " + managerId + "]";
    }

}
