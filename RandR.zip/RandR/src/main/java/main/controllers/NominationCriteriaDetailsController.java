package main.controllers;


import main.beans.NominationCriteriaDetails;
import main.services.NominationCriteriaDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/nominationCriteriaDetails")
public class NominationCriteriaDetailsController {


    @Autowired
    private NominationCriteriaDetailsService nominationCriteriaDetailsService;

    //  to save
    @PostMapping("/save")
    public NominationCriteriaDetails save(@Valid @RequestBody NominationCriteriaDetails nominationCriteriaDetails)
    {
        return nominationCriteriaDetailsService.save( nominationCriteriaDetails );
    }

    // to retrieve all details
    @GetMapping("/all")
    public List<NominationCriteriaDetails> getAll()
    {
        return nominationCriteriaDetailsService.findAll();
    }

    // to retrieve by id
    @GetMapping("/getByRewardType/{REWARD_TYPE}")
    public List<NominationCriteriaDetails> getByRewardType(@PathVariable("REWARD_TYPE") final String REWARD_TYPE)
    {
        return nominationCriteriaDetailsService.getByRewardType(REWARD_TYPE);
    }
}
