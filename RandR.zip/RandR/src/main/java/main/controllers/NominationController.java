package main.controllers;

import main.beans.NominationEntity;
import main.services.NominationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/nomination")
public class NominationController {

    @Autowired
    private NominationService nominationService;

    //  to save
    @PostMapping("/save")
    public NominationEntity createEmployee(@Valid @RequestBody NominationEntity nominationEntity) {
        return nominationService.save( nominationEntity );
    }

    // to retrieve all details
    @GetMapping("/all")
    public List<NominationEntity> getAll() {
        return nominationService.findAll();
    }

    //  to retrieve by id
    @GetMapping("/getByid/{NOMINEE_ID}")
    public Optional<NominationEntity> getId(@PathVariable("NOMINEE_ID") final Integer NOMINEE_ID) {
        return nominationService.getId( NOMINEE_ID );
    }

    //  to update
    @PutMapping("/update")
    public NominationEntity update(@RequestBody NominationEntity nominationEntity) {
        return nominationService.update( nominationEntity );
    }

    // Save nomination and remarks

    @PostMapping("/saveNomination")
    public NominationEntity saveNomination(@Valid @RequestBody NominationEntity nominationEntity) {
        return nominationService.saveNomination( nominationEntity );
    }
}
