package main.controllers;

import main.beans.Points;
import main.services.PointsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/points")
@CrossOrigin(origins = "*",allowedHeaders = "*")
public class PointsController
{
    @Autowired
    private PointsService pointsService;

    /*  to save*/
    @PostMapping("/save")
    public Points createEmployee(@Valid @RequestBody Points points)
    {
        return pointsService.save(points);
    }

    /*to retrieve all*/
    @GetMapping("/all")
    public List<Points> getAll()
    {
        return pointsService.getAll();
    }

    /*  to retrieve by id*/
    @GetMapping("/getByid/{REWARD_TYPE}")
    public Optional<Points> getId(@PathVariable("REWARD_TYPE") final String REWARD_TYPE)
    {
        return pointsService.getById(REWARD_TYPE);
    }


    /* to update all*/
   @PutMapping("/update")
   public Points update(@RequestBody Points points)
   {
       return  pointsService.update(points);
   }
}
