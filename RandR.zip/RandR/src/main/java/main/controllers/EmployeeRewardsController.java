package main.controllers;


import main.beans.EmployeeEntity;

import main.services.EmployeeRewardsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/employeeRewards")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EmployeeRewardsController {

    @Autowired
    private EmployeeRewardsService employeeRewardsService;

    //  to save
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeEntity createEmployee(@Valid @RequestBody EmployeeEntity employeeEntity) {
        return employeeRewardsService.save(employeeEntity);
    }

    // to retrieve all details
    @GetMapping("/all")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeEntity> getAll() {
        return employeeRewardsService.findAll();
    }

    /*  to retrieve by employee id*/
    @GetMapping("/getByEmployeeId/{EMP_ID}")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeEntity> getId(@PathVariable("EMP_ID") final Integer EMP_ID) {
        return employeeRewardsService.getId(EMP_ID);
    }

    // to retrieve by employee id
    @GetMapping("/getByManagerId/{MANAGER_ID}")
    @ResponseStatus(HttpStatus.OK)
    public List<EmployeeEntity> getByManagerId(@PathVariable("MANAGER_ID") final Integer MANAGER_ID) {
        return employeeRewardsService.getByManagerId(MANAGER_ID);
    }

    //  to update
    @PutMapping("/update")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeEntity update(@RequestBody EmployeeEntity employeeEntity) {
        return employeeRewardsService.update(employeeEntity);
    }
}
