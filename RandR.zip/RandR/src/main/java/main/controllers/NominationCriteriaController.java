package main.controllers;

import main.beans.NominationCriteriaDetails;
import main.beans.NominationCriteria;
import main.services.NominationCriteriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/nominationCriteria")
public class NominationCriteriaController {

    @Autowired
    private NominationCriteriaService nominationCriteriaService;

    /*  to save*/
    @PostMapping("/save")
    public NominationCriteria createEmployee(@Valid @RequestBody NominationCriteria nominationCriteria)
    {
        return nominationCriteriaService.save( nominationCriteria );
    }

/* to retrieve all details*/
    @GetMapping("/all")
    public List<NominationCriteria> getAll()
    {
        return nominationCriteriaService.findAll();
    }

/* to retrieve by id*/
    @GetMapping("/getByRewardType/{REWARD_TYPE}")
    public List<NominationCriteria> getId(@PathVariable("REWARD_TYPE") final String REWARD_TYPE)
    {
        return nominationCriteriaService.getId(REWARD_TYPE);
    }

/*  to update*/
    @PutMapping("/update")
    public NominationCriteria update(@RequestBody NominationCriteria nominationCriteria)
    {
        return  nominationCriteriaService.update( nominationCriteria );
    }
}
