package main.controllers;

import main.beans.EmployeeEntity;
import main.services.ExcelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ExcelController {

    @Autowired
    private ExcelService excelService;

    /*
    @GetMapping("/readExcel")
    public List<EmployeeEntity> readExcel() throws IOException, ParseException {
        List<EmployeeEntity> employeeEntities = excelService.readExcel();
        return employeeEntities;
    }
    */
    @PostMapping("/excelReader")
    public List<EmployeeEntity> excelReader(@RequestParam("file") MultipartFile excelDatafile) throws IOException, ParseException {
        return excelService.readExcel( excelDatafile );
    }
}
