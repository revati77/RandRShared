package MainClass.Services;

import MainClass.Beans.EmployeeEntity;
import MainClass.Repositories.EmployeeRewardsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeRewardsService {

    @Autowired
    private EmployeeRewardsRepository employeeRewardsRepository;

    /*    To save */
    public EmployeeEntity save(EmployeeEntity employeeEntity) {
        return employeeRewardsRepository.save( employeeEntity );
    }

    /* retrieve all employeerole details*/
    public List<EmployeeEntity> findAll() {
        return employeeRewardsRepository.findAll();
    }

    /*    Get by an id*/
//    public List<EmployeeEntity> getId(Integer EMP_ID) {
//        return employeeRewardsRepository.findByEmpid( EMP_ID );
//
//    }

    /*    to update*/
    public EmployeeEntity update(EmployeeEntity employeeEntity) {
        return employeeRewardsRepository.save( employeeEntity );
    }

}
