package MainClass.Services;

import MainClass.Beans.NominationCriteria;
import MainClass.Repositories.NominationCriteriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NominationCriteriaService {

    @Autowired
    private NominationCriteriaRepository nominationCriteriaRepository;

//To save

    public NominationCriteria save(NominationCriteria nominationCriteria) {
        return nominationCriteriaRepository.save(nominationCriteria);
    }

// retrieve all employeerole details

    public List<NominationCriteria> findAll() {
        return nominationCriteriaRepository.findAll();
    }

//    Get by an reward type

    public List<NominationCriteria> getId(String REWARD_TYPE) {
        return nominationCriteriaRepository.findByRewardType(REWARD_TYPE);
    }

// to update

    public NominationCriteria update(NominationCriteria nominationCriteria) {
        return nominationCriteriaRepository.save(nominationCriteria);
    }
}
