package MainClass.Services;

import MainClass.Beans.EmployeeRole;
import MainClass.Repositories.EmployeeRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeRoleService {

    @Autowired
    private EmployeeRoleRepository employeeRoleRepository;

    /*    To save */
    public EmployeeRole save(EmployeeRole employeerole) {
        return employeeRoleRepository.save( employeerole );
    }

    /* retrieve all employeerole details*/
    public List<EmployeeRole> findAll() {
        return employeeRoleRepository.findAll();
    }

    /*    Get by an id*/
    public Optional<EmployeeRole> findById(Integer EMP_ID) {
        return employeeRoleRepository.findById( EMP_ID );
    }

    /*    to update*/
    public EmployeeRole update(EmployeeRole employeerole) {
        return employeeRoleRepository.save( employeerole );
    }

    public String getRole(Integer EMP_ID, String PASSWORD) {
        String emp_role = null;
        Optional<EmployeeRole> employee = findById( EMP_ID );
        if (employee.isPresent()) {
            String emp_password = employee.get().getPassword();
            if (emp_password.equals( PASSWORD )) {
                emp_role = employee.get().getEmpRole();
            } else {
                System.out.println( "Invalid Password" );
            }
        } else {
            System.out.println( "Invalid Username" );
        }
        return emp_role;
    }
}