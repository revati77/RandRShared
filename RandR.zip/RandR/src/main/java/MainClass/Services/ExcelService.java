package MainClass.Services;

import MainClass.Beans.EmployeeEntity;
import MainClass.excel.ExcelReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@Component
public class ExcelService {

    @Autowired
    private ExcelReader excelReader;

    public List<EmployeeEntity> readExcel() throws IOException, ParseException {
        List<EmployeeEntity> employeeEntities = excelReader.read();
        return employeeEntities;
    }

}
