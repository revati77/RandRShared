package MainClass.Repositories;


import MainClass.Beans.EmployeeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface EmployeeRewardsRepository extends JpaRepository<EmployeeEntity,Long> {
 //   @Query("select e from EmployeeEntity e where e.EMP_ID=?1")
//    @Query(value = "select e from employeerewards e where EMP_ID=?1", nativeQuery = true)
  //  List<EmployeeEntity> findByEmpid(Integer EMP_ID);
}
