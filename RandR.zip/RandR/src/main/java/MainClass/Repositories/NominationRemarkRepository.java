package MainClass.Repositories;

import MainClass.Beans.NominationRemark;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NominationRemarkRepository extends JpaRepository<NominationRemark,Long> {
}
