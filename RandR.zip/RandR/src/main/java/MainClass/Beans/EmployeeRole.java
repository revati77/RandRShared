package MainClass.Beans;

import javax.persistence.*;

@Entity
@Table(name = "employeerole")

public class EmployeeRole {

    @Id
    @Column(name = "EMP_ID")
    private Integer empid;

    @Column(name = "EMP_NAME")
    private String empname;
    @Column(name = "EMP_ROLE")
    private String emprole;

    @Column(name = "MANAGER_ID")
    private Long managerid;
    @Column(name = "PASSWORD")
    private String password;

    public Integer getEmpid() {
        return empid;
    }

    public void setEmpid(Integer empid) {
        this.empid = empid;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getEmprole() {
        return emprole;
    }

    public void setEmprole(String emprole) {
        this.emprole = emprole;
    }

    public Long getManagerid() {
        return managerid;
    }

    public void setManagerid(Long managerid) {
        this.managerid = managerid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "EmployeeRole [Employee Id= "+empid+",Employee Name= "+empname+",Employee Role= "+emprole+",Manager Id= "+managerid+"]";
    }

}
