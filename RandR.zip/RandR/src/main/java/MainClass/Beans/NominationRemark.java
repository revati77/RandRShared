package MainClass.Beans;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

@Entity
@Table(name="nominationremark")
public class NominationRemark {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer REMARK_ID;

    private Long ID;
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID", insertable = false,updatable = false)
    private NominationEntity nomination;

private Integer CRITERIA_ID;
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    private NominationCriteria nominationcriteria;


    private String REMARK;

    //Getters and Setters and Constructor

    public NominationRemark() {
    }

    public Integer getREMARK_ID() {
        return REMARK_ID;
    }

    public void setREMARK_ID(Integer REMARK_ID) {
        this.REMARK_ID = REMARK_ID;
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public NominationEntity getNomination() {
        return nomination;
    }

    public void setNomination(NominationEntity nomination) {
        this.nomination = nomination;
    }

    public Integer getCRITERIA_ID() {
        return CRITERIA_ID;
    }

    public void setCRITERIA_ID(Integer CRITERIA_ID) {
        this.CRITERIA_ID = CRITERIA_ID;
    }

    public NominationCriteria getNominationcriteria() {
        return nominationcriteria;
    }

    public void setNominationcriteria(NominationCriteria nominationcriteria) {
        this.nominationcriteria = nominationcriteria;
    }

    public String getREMARK() {
        return REMARK;
    }

    public void setREMARK(String REMARK) {
        this.REMARK = REMARK;
    }
}
