package MainClass.Controllers;

import MainClass.Beans.EmployeeEntity;
import MainClass.Services.ExcelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ExcelController {

    @Autowired
    private ExcelService excelService;

    @GetMapping("/readExcel")
    public List<EmployeeEntity> readExcel() throws IOException, ParseException {

        List<EmployeeEntity> employeeEntities = excelService.readExcel();
        return employeeEntities;
    }

}
