package MainClass.Controllers;

import MainClass.Beans.NominationRemark;
import MainClass.Services.NominationRemarkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/nominationRemark")
public class NominationRemarkController {

    @Autowired
    private NominationRemarkService nominationRemarkService;

/*  to save*/
    @PostMapping("/save")
    public NominationRemark createEmployee(@Valid @RequestBody NominationRemark nominationRemark)
    {
        return nominationRemarkService.save(nominationRemark);
    }

/* to retrieve all details*/

    @GetMapping("/all")
    public List<NominationRemark> getAll()
    {
        return nominationRemarkService.findAll();
    }

/*  to retrieve by id*/
    @GetMapping("/getById/{ID}")
    public Optional<NominationRemark> getId(@PathVariable("ID") final Long ID)
    {
        return nominationRemarkService.getId(ID);
    }


/*  to update*/
    @PutMapping("/update")
    public NominationRemark update(@RequestBody NominationRemark nominationRemark)
    {
        return  nominationRemarkService.update(nominationRemark);
    }
}
