package MainClass.Controllers;

import MainClass.Beans.EmployeeCompoff;
import MainClass.Beans.EmployeeRole;
import MainClass.Services.ReadCompOffDetails;
import MainClass.Services.AddEmployeeRole;
import MainClass.Services.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@CrossOrigin(origins = "*",allowedHeaders = "*")
@RequestMapping
public class RestC {
    private final FileService fileService;

    @Autowired
    AddEmployeeRole addEmployeeRole;
    @Autowired
    ReadCompOffDetails readCompOffDetails;


    @GetMapping(value="/employee-roles")
    public ResponseEntity<List<EmployeeRole>> getAllEmployees()
    {
        List<EmployeeRole> list=addEmployeeRole.getAllEmployees();
        System.out.print(list);
        return new ResponseEntity<List<EmployeeRole>>(list,new HttpHeaders(),HttpStatus.OK);
    }

    @Autowired
    public RestC(FileService fileService)
    {
        this.fileService = fileService;
    }

    @PostMapping(value="/api/files")
    @ResponseStatus(HttpStatus.OK)
    public void handleFileUpload(@RequestParam("file")MultipartFile file) throws IOException{
        fileService.storeFile(file);
    }

    @GetMapping(value = "/readCompOff")
    public ResponseEntity<List<EmployeeCompoff>> readExcelData()
    {
        List<EmployeeCompoff> list=readCompOffDetails.readExcelData("C:\\Users\\pranjal.goyal\\Documents\\Rewards&RecognitionDocuments\\SampleSheet.xlsx");
//        System.out.print(list);
        return new ResponseEntity<List<EmployeeCompoff>>(list,new HttpHeaders(),HttpStatus.OK);
    }


    @GetMapping(value="/res")
    public static String res()
    {
        return "Its Working";
    }

}
