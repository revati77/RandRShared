package MainClass.excel;

import MainClass.Beans.EmployeeEntity;
import MainClass.Repositories.EmployeeRewardsRepository;
import MainClass.Services.CalculatePoints;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Component

public class ExcelReader {

    /*  public static void main(String[] args) throws IOException {
           ExcelReader excelReader = new ExcelReader();
           excelReader.read();
       }
     */

    @Autowired
    EmployeeRewardsRepository employeeRewardsRepository;

    @Autowired
    CalculatePoints calculatePoints;

    public List<EmployeeEntity> read() throws IOException, ParseException {

        XSSFWorkbook xssfWorkbook = new XSSFWorkbook( new FileInputStream( new File( "C:\\Users\\rashmi.n\\RandR\\Excel\\sample.xlsx" ) ) );
        // XSSFWorkbook xssfWorkbook = new XSSFWorkbook(new FileInputStream(new File("C:\\CodeBase\\Rashu\\Employees.xlsx")));
        XSSFSheet xssfSheet = xssfWorkbook.getSheet( "employee" );
        Iterator iterator = xssfSheet.iterator();
        //HSSFWorkbook hssfWorkbook = new HSSFWorkbook(new FileInputStream(new File("C:\\Users\\rashmi.n\\RandR\\sample.xlsx")));
        //HSSFSheet hssfSheet = hssfWorkbook.getSheet("employee");
        //Iterator iterator = hssfSheet.iterator();

        List<EmployeeEntity> employeeEntities = new ArrayList<>();

        while (iterator.hasNext()) {

            Row row = (Row) iterator.next();

            if (row.getRowNum() == 0) continue; //just skip the rows if row number is 0

            EmployeeEntity employeeEntity = new EmployeeEntity();

            employeeEntity.setEmpId( (int) row.getCell( 0 ).getNumericCellValue() );
            employeeEntity.setEmpName( row.getCell( 1 ).getStringCellValue() );
            employeeEntity.setRewardType( row.getCell( 2 ).getStringCellValue() );
            int noOfInterviews = new Double( row.getCell( 3 ).getNumericCellValue() ).intValue();
            employeeEntity.setNoOfInterviews( noOfInterviews );
            //       String date = row.getCell(4).getStringCellValue();
            //     employeeEntity.setDATE_OF(date);

            //     Date dateFormat =  new SimpleDateFormat("DD-MM-YYYY").parse(row.getCell(4).getStringCellValue());
            //    employeeEntity.setDATE_OF(dateFormat);
            //   employeeEntity.setDATE_OF(row.getCell(4).getDateCellValue());
            int managerId = new Double( row.getCell( 5 ).getNumericCellValue() ).intValue();
            employeeEntity.setManagerId( managerId );

            Integer points = calculatePoints.CalculateTotalPoints( employeeEntity.getRewardType(), employeeEntity.getNoOfInterviews() );
            employeeEntity.setNoOfPoints( points );

            employeeRewardsRepository.save(employeeEntity);
            employeeEntities.add( employeeEntity );

        }


        return employeeEntities;
    }

}
